'use strict';

/**
 * 合并闭区间数组。
 * @param {Array<[number, number]>} ranges 若干 [start, end]（start <= end），未排序、可能重复、可为空。
 * @returns {Array<[number, number]>} 合并后的区间，按 start 升序、互不重叠。
 * 不修改入参（数组本身、顺序及每个子数组内容均保持不变）。
 */
function mergeRanges(ranges) {
  if (!Array.isArray(ranges) || ranges.length === 0) return [];

  // 拷贝每个区间，绝不触碰入参
  const sorted = ranges.map((r) => [r[0], r[1]]);
  sorted.sort((a, b) => a[0] - b[0] || a[1] - b[1]);

  const merged = [];
  let curStart = sorted[0][0];
  let curEnd = sorted[0][1];

  for (let i = 1; i < sorted.length; i++) {
    const s = sorted[i][0];
    const e = sorted[i][1];
    // 闭区间：只要存在公共点就必须合并，即 s <= curEnd
    if (s <= curEnd) {
      if (e > curEnd) curEnd = e;
    } else {
      merged.push([curStart, curEnd]);
      curStart = s;
      curEnd = e;
    }
  }
  merged.push([curStart, curEnd]);
  return merged;
}

module.exports = { mergeRanges };
