'use strict';

const assert = require('node:assert/strict');
const { mergeRanges } = require('./merge_ranges');

let passed = 0;
function check(name, actual, expected) {
  assert.deepStrictEqual(actual, expected);
  passed += 1;
  console.log('ok - ' + name);
}

// 1. 空输入
check('empty input', mergeRanges([]), []);

// 2. 未排序输入
check('unsorted input', mergeRanges([[5, 7], [1, 3], [2, 4], [10, 12]]), [[1, 4], [5, 7], [10, 12]]);
check('unsorted single merged', mergeRanges([[8, 10], [1, 5], [3, 9]]), [[1, 10]]);

// 3. 重复区间
check('duplicate ranges', mergeRanges([[2, 4], [2, 4], [1, 3], [2, 4]]), [[1, 4]]);

// 4. 单点区间
check('single-point ranges', mergeRanges([[3, 3], [1, 1], [5, 5]]), [[1, 1], [3, 3], [5, 5]]);
check('point inside range', mergeRanges([[1, 5], [3, 3]]), [[1, 5]]);
check('point touching boundary', mergeRanges([[1, 2], [2, 2]]), [[1, 2]]);

// 5. 闭区间相邻必须合并（有公共点）
check('closed touching must merge', mergeRanges([[1, 2], [2, 3]]), [[1, 3]]);
check('chain touching must merge', mergeRanges([[1, 2], [2, 3], [3, 4]]), [[1, 4]]);

// 6. 相邻但无公共点禁止合并
check('adjacent without common point must NOT merge', mergeRanges([[1, 1], [2, 2]]), [[1, 1], [2, 2]]);
check('gap ranges stay separate', mergeRanges([[1, 2], [4, 5]]), [[1, 2], [4, 5]]);

// 7. 含负数区间
check('negative ranges', mergeRanges([[-5, -1], [-3, 2], [4, 6]]), [[-5, 2], [4, 6]]);
check('negative crossing zero', mergeRanges([[-2, 0], [0, 3]]), [[-2, 3]]);
check('all negative', mergeRanges([[-10, -8], [-9, -6], [-5, -1]]), [[-10, -6], [-5, -1]]);

// 8. 入参不被修改（快照对比）
const input = [[5, 7], [1, 3], [2, 4], [9, 9], [1, 3]];
const snapshot = JSON.stringify(input);
mergeRanges(input);
assert.strictEqual(JSON.stringify(input), snapshot, 'input must not be mutated');
passed += 1;
console.log('ok - input array not mutated (snapshot comparison)');

// 深拷贝层级校验：每个子数组内容与引用均未被改
const input2 = [[3, 1].sort((a, b) => a - b), [0, 2]];
const inner0 = input2[0];
const inner1 = input2[1];
mergeRanges(input2);
assert.strictEqual(input2[0], inner0);
assert.strictEqual(input2[1], inner1);
assert.deepStrictEqual(inner0, [1, 3]);
assert.deepStrictEqual(inner1, [0, 2]);
passed += 1;
console.log('ok - nested sub-arrays untouched (reference + content)');

console.log('\nAll ' + passed + ' tests passed.');
