'use strict';
const { execSync } = require('child_process');
function runSolver(coords) {
  const input = coords.map(p => p.join(' ')).join('\n') + '\n';
  const out = execSync('node tour.js', { input, encoding: 'utf8', timeout: 60000 }).trim();
  return out.split(/\s+/).map(Number);
}
function checkPerm(t, n, label) {
  if (t.length !== n) throw new Error(label + ': length must be N, got ' + t.length);
  const seen = new Set(t);
  if (seen.size !== n) throw new Error(label + ': duplicate or missing indices');
  for (const v of t) if (!Number.isInteger(v) || v < 0 || v >= n) throw new Error(label + ': index out of range: ' + v);
}
function tourLen(t, pts) {
  let s = 0;
  for (let i = 0; i < t.length; i++) {
    const a = pts[t[i]], b = pts[t[(i + 1) % t.length]];
    s += Math.hypot(a[0] - b[0], a[1] - b[1]);
  }
  return s;
}
function seededRand(seed) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}
// Instance 1: 60 cities on 3 concentric rings
const inst1 = [];
const r1 = seededRand(42);
for (let ring = 1; ring <= 3; ring++) {
  for (let i = 0; i < 20; i++) {
    const ang = (i / 20) * 2 * Math.PI + ring * 0.3;
    const rad = ring * 30 + (r1() - 0.5) * 6;
    inst1.push([rad * Math.cos(ang), rad * Math.sin(ang)]);
  }
}
// Instance 2: 100 uniform random cities
const inst2 = [];
const r2 = seededRand(1234);
for (let i = 0; i < 100; i++) inst2.push([r2() * 1000, r2() * 1000]);
// Instance 3: 5 tight clusters of 10 cities each
const inst3 = [];
const r3 = seededRand(7);
const centers = [[0,0],[100,0],[0,100],[100,100],[50,50]];
for (const c of centers) for (let i = 0; i < 10; i++) inst3.push([c[0] + (r3()-0.5)*10, c[1] + (r3()-0.5)*10]);
for (const [label, pts] of [['rings-60', inst1], ['random-100', inst2], ['clusters-50', inst3]]) {
  const t0 = Date.now();
  const tour = runSolver(pts);
  const ms = Date.now() - t0;
  checkPerm(tour, pts.length, label);
  console.log(label + ': N=' + pts.length + ' valid permutation, tour length = ' + tourLen(tour, pts).toFixed(4) + ' (' + ms + 'ms)');
}
console.log('ALL SELFTESTS PASSED');