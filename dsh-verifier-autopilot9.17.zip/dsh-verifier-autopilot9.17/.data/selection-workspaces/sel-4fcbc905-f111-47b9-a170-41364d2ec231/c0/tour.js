'use strict';
// TSP heuristic: multi-start nearest neighbor + 2-opt improvement.
const fs = require('fs');
const input = fs.readFileSync(0, 'utf8').trim().split(/\n+/).filter(l => l.trim().length);
const pts = input.map(l => { const [x, y] = l.trim().split(/\s+/).map(Number); return [x, y]; });
const n = pts.length;
const dist = [];
for (let i = 0; i < n; i++) dist.push(new Float64Array(n));
for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
  const dx = pts[i][0] - pts[j][0], dy = pts[i][1] - pts[j][1];
  const d = Math.hypot(dx, dy);
  dist[i][j] = d; dist[j][i] = d;
}
function tourLen(t) {
  let s = 0;
  for (let i = 0; i < n; i++) s += dist[t[i]][t[(i + 1) % n]];
  return s;
}
function nearestNeighbor(start) {
  const used = new Array(n).fill(false);
  const t = [start]; used[start] = true;
  for (let k = 1; k < n; k++) {
    const last = t[t.length - 1];
    let best = -1, bd = Infinity;
    for (let j = 0; j < n; j++) if (!used[j] && dist[last][j] < bd) { bd = dist[last][j]; best = j; }
    t.push(best); used[best] = true;
  }
  return t;
}
function twoOpt(t) {
  let improved = true, guard = 0;
  while (improved && guard < 100000) {
    improved = false; guard++;
    for (let i = 0; i < n - 1; i++) {
      const a = t[i], b = t[(i + 1) % n];
      for (let k = i + 2; k < i + n - 1; k++) {
        const kk = k % n, kn = (k + 1) % n;
        const c = t[kk], d = t[kn];
        if (dist[a][c] + dist[b][d] < dist[a][b] + dist[c][d] - 1e-12) {
          let lo = i + 1, hi = kk;
          while (lo < hi) {
            const tmp = t[lo % n]; t[lo % n] = t[hi % n]; t[hi % n] = tmp;
            lo++; hi--;
          }
          improved = true;
        }
      }
    }
  }
  return t;
}
if (n <= 2) {
  console.log(Array.from({ length: n }, (_, i) => i).join(' '));
} else {
  let best = null, bestLen = Infinity;
  const starts = new Set([0]);
  while (starts.size < Math.min(n, 15)) starts.add(Math.floor(Math.random() * n));
  for (const s of starts) {
    const t = twoOpt(nearestNeighbor(s).slice());
    const L = tourLen(t);
    if (L < bestLen) { bestLen = L; best = t; }
  }
  console.log(best.join(' '));
}