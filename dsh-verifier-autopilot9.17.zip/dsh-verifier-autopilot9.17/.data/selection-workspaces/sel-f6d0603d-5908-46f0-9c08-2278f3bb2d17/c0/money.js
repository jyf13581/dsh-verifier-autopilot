"use strict";

function assertInt(name, v) {
  if (!Number.isSafeInteger(v)) {
    throw new TypeError(name + " must be a safe integer (amount in cents)");
  }
}

function add(a, b) {
  assertInt("a", a);
  assertInt("b", b);
  const r = a + b;
  assertInt("result", r);
  return r;
}

function sub(a, b) {
  assertInt("a", a);
  assertInt("b", b);
  const r = a - b;
  assertInt("result", r);
  return r;
}

function format(cents) {
  assertInt("cents", cents);
  const neg = cents < 0;
  // Math.abs avoids -0 edge case visually ("¥0.00" not "-¥0.00")
  const abs = Math.abs(cents);
  const yuan = Math.floor(abs / 100);
  const frac = String(abs % 100).padStart(2, "0");
  const grouped = String(yuan).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (neg ? "-¥" : "¥") + grouped + "." + frac;
}

module.exports = { add, sub, format };
