"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { add, sub, format } = require("./money.js");

test("add: positive amounts", () => {
  assert.equal(add(100, 200), 300);
  assert.equal(add(1, 2), 3);
});

test("add: negative and mixed amounts", () => {
  assert.equal(add(-100, -50), -150);
  assert.equal(add(100, -150), -50);
  assert.equal(add(0, 0), 0);
});

test("sub: positive and negative results", () => {
  assert.equal(sub(300, 100), 200);
  assert.equal(sub(100, 300), -200);
  assert.equal(sub(-100, -100), 0);
});

test("add/sub: rejects non-integer input", () => {
  assert.throws(() => add(0.1, 0.2), TypeError);
  assert.throws(() => sub(1.5, 1), TypeError);
  assert.throws(() => add(Number.MAX_SAFE_INTEGER, 1), TypeError);
});

test("format: positive amounts", () => {
  assert.equal(format(0), "¥0.00");
  assert.equal(format(1), "¥0.01");
  assert.equal(format(99), "¥0.99");
  assert.equal(format(100), "¥1.00");
  assert.equal(format(105), "¥1.05");
  assert.equal(format(123456), "¥1,234.56");
  assert.equal(format(123456789), "¥1,234,567.89");
});

test("format: negative amounts", () => {
  assert.equal(format(-1), "-¥0.01");
  assert.equal(format(-123456), "-¥1,234.56");
  assert.equal(format(-123456789), "-¥1,234,567.89");
});

test("format: thousands-grouping boundaries", () => {
  assert.equal(format(99999), "¥999.99");
  assert.equal(format(100000), "¥1,000.00");
  assert.equal(format(99999999), "¥999,999.99");
  assert.equal(format(100000000), "¥1,000,000.00");
  assert.equal(format(-99999), "-¥999.99");
  assert.equal(format(-100000), "-¥1,000.00");
});

test("format: rejects non-integer input", () => {
  assert.throws(() => format(1.5), TypeError);
});
