"use strict";

// Format a duration in whole minutes as "Xh Ym" (or "Ym" when under an hour).
// Examples: 0 -> "0m", 59 -> "59m", 75 -> "1h 15m", 125 -> "2h 5m".
function fmt(m) {
  if (!Number.isSafeInteger(m) || m < 0) {
    throw new TypeError("m must be a non-negative integer (minutes)");
  }
  const h = Math.floor(m / 60);
  const mins = m % 60;
  return h === 0 ? `${mins}m` : `${h}h ${mins}m`;
}

module.exports = { fmt };
