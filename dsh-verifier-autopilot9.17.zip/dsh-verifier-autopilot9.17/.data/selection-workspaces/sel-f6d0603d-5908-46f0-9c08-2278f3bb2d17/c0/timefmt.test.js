"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { fmt } = require("./timefmt.js");

test("fmt: under an hour yields minutes only", () => {
  assert.equal(fmt(0), "0m");
  assert.equal(fmt(59), "59m");
});

test("fmt: hours and minutes", () => {
  assert.equal(fmt(75), "1h 15m");
  assert.equal(fmt(125), "2h 5m");
});
