# live-chain fixture - Small fixture repo used to exercise autopilot end-to-end.
