xs = [1, 2, 3, 4]
print(sum(xs) / len(xs))
