'use strict';
const assert = require('node:assert');
const { add, sub, mul, allocate } = require('./money');

assert.strictEqual(add("0.1", "0.2"), "0.30");
assert.strictEqual(mul("0.105", "1"), "0.11");
assert.strictEqual(mul("-0.105", "1"), "-0.11");
assert.strictEqual(sub("0.30", "0.10"), "0.20");
assert.deepStrictEqual(allocate("0.05", [1, 1, 1]), ["0.02", "0.02", "0.01"]);
assert.deepStrictEqual(allocate("1.00", [1, 1, 1]), ["0.34", "0.33", "0.33"]);

console.log('add("0.1","0.2") ===', JSON.stringify(add("0.1","0.2")));
console.log('mul("0.105","1") ===', JSON.stringify(mul("0.105","1")));
console.log('allocate("0.05",[1,1,1]) ===', JSON.stringify(allocate("0.05",[1,1,1])));
console.log('allocate("1.00",[1,1,1]) ===', JSON.stringify(allocate("1.00",[1,1,1])));
console.log('ALL TESTS PASSED');
