// money.js — exact decimal money arithmetic (no binary float error)
'use strict';

// Parse a decimal string to integer cents. Throws on invalid input.
function toCents(s) {
  if (typeof s !== 'string' || !/^-?\d+(\.\d+)?$/.test(s.trim())) {
    throw new Error('invalid amount: ' + s);
  }
  s = s.trim();
  const neg = s.startsWith('-');
  if (neg) s = s.slice(1);
  const [intPart, fracPart = ''] = s.split('.');
  // Keep at most 2 frac digits semantics? No: amounts may carry >2 decimals (e.g. "0.105").
  // Represent as exact rational: value = int * 100 + frac scaled, but to keep integer math
  // we work in 1/1000-ish units only when needed. Simpler: parse to exact decimal digits.
  return { neg, intPart, fracPart };
}

// Exact decimal -> rational as [sign, numerator, denominatorPower10]
function toRational(s) {
  if (typeof s !== 'string') throw new Error('amount must be a string');
  const t = s.trim();
  if (!/^-?\d+(\.\d+)?$/.test(t)) throw new Error('invalid amount: ' + s);
  const neg = t.startsWith('-');
  const body = neg ? t.slice(1) : t;
  const dot = body.indexOf('.');
  const intPart = dot === -1 ? body : body.slice(0, dot);
  const fracPart = dot === -1 ? '' : body.slice(dot + 1);
  const num = BigInt(intPart + fracPart);
  return { neg, num, den: 10n ** BigInt(fracPart.length) };
}

function normalize(r) {
  // reduce not needed for our ops; keep den as power of 10
  if (r.num === 0n) r.neg = false;
  return r;
}

function align(a, b) {
  if (a.den === b.den) return [a, b];
  if (a.den > b.den) {
    const f = a.den / b.den;
    b = { neg: b.neg, num: b.num * f, den: a.den };
  } else {
    const f = b.den / a.den;
    a = { neg: a.neg, num: a.num * f, den: b.den };
  }
  return [a, b];
}

function addRational(a, b, subtract) {
  [a, b] = align(a, b);
  let an = a.neg ? -a.num : a.num;
  let bn = b.neg ? -b.num : b.num;
  if (subtract) bn = -bn;
  const s = an + bn;
  return normalize({ neg: s < 0n, num: s < 0n ? -s : s, den: a.den });
}

// Round rational to cents, half-up on absolute value, sign restored.
function roundToCents(r) {
  const scaled = r.num * 100n; // value * 100 / den
  const q = scaled / r.den;
  const rem = scaled % r.den;
  let cents = q;
  if (rem * 2n >= r.den) cents += 1n; // round half up on absolute value
  if (r.neg) cents = -cents;
  if (cents === 0n) return '0.00';
  const neg = cents < 0n;
  let c = neg ? -cents : cents;
  return (neg ? '-' : '') + (c / 100n).toString() + '.' + (c % 100n).toString().padStart(2, '0');
}

// Floor rational to integer cents (toward zero is fine since inputs here are non-negative for allocate).
function floorCents(r) {
  const scaled = r.num * 100n;
  return scaled / r.den; // r non-negative in allocate usage
}

function formatCents(c) {
  // c is a BigInt of cents, may be negative
  if (c === 0n) return '0.00';
  const neg = c < 0n;
  const v = neg ? -c : c;
  return (neg ? '-' : '') + (v / 100n).toString() + '.' + (v % 100n).toString().padStart(2, '0');
}

function add(a, b) {
  return roundToCents(addRational(toRational(a), toRational(b), false));
}

function sub(a, b) {
  return roundToCents(addRational(toRational(a), toRational(b), true));
}

function mul(amount, k) {
  if (typeof k === 'string') {
    if (!/^-?\d+(\.\d+)?$/.test(k.trim())) throw new Error('invalid multiplier: ' + k);
  } else if (typeof k !== 'number' || !Number.isFinite(k)) {
    throw new Error('invalid multiplier: ' + k);
  }
  const r = toRational(amount);
  const ks = k.toString();
  // exact decimal parse of k (reject exponent edge cases by handling them)
  let kr;
  if (/e/i.test(ks)) {
    // expand scientific notation exactly
    const [m, e] = ks.toLowerCase().split('e');
    const exp = parseInt(e, 10);
    const dot = m.indexOf('.');
    const digits = (dot === -1 ? m : m.slice(0, dot) + m.slice(dot + 1)).replace('-', '');
    const neg = m.startsWith('-');
    let num = BigInt(digits);
    let denPow = (dot === -1 ? 0 : m.length - dot - 1) - exp;
    if (denPow >= 0) kr = { neg, num, den: 10n ** BigInt(denPow) };
    else { for (let i = 0; i < -denPow; i++) num *= 10n; kr = { neg, num, den: 1n }; }
  } else {
    kr = toRational(ks);
  }
  const prod = {
    neg: r.neg !== kr.neg,
    num: r.num * kr.num,
    den: r.den * kr.den,
  };
  return roundToCents(normalize(prod));
}

function allocate(total, weights) {
  if (!Array.isArray(weights) || weights.length === 0) throw new Error('weights must be a non-empty array');
  let wSum = 0n;
  const wBig = weights.map((w) => {
    if (typeof w === 'bigint') { if (w < 0n) throw new Error('weights must be non-negative integers'); return w; }
    if (!Number.isInteger(w) || w < 0) throw new Error('weights must be non-negative integers');
    return BigInt(w);
  });
  for (const w of wBig) wSum += w;
  if (wSum === 0n) throw new Error('at least one weight must be positive');

  const totalCentsStr = mul(total, '1'); // round total to cents exactly
  // parse back to cents bigint
  const neg = totalCentsStr.startsWith('-');
  if (neg) throw new Error('total must be non-negative');
  const [i, f] = totalCentsStr.split('.');
  let remaining = BigInt(i) * 100n + BigInt(f);

  const r = toRational(total);
  const shares = wBig.map((w) => {
    const exact = { neg: false, num: r.num * w * 100n, den: r.den * wSum }; // cents
    return exact.num / exact.den;
  });
  let assigned = 0n;
  for (const s of shares) assigned += s;
  let leftover = remaining - assigned;

  // order: weight desc, then index asc
  const order = wBig.map((w, i) => [w, i]).sort((a, b) => (a[0] === b[0] ? a[1] - b[1] : a[0] > b[0] ? -1 : 1));
  let idx = 0;
  while (leftover > 0n) {
    shares[order[idx % order.length][1]] += 1n;
    leftover -= 1n;
    idx += 1;
  }
  return shares.map(formatCents);
}

module.exports = { add, sub, mul, allocate };
