'use strict';
// money.js - decimal-safe money arithmetic, exact rational via BigInt.

// Parse a decimal string into { v, scale }: value = v / 10^scale (exact).
function parseDecimal(s) {
  if (typeof s === 'number') s = String(s);
  if (typeof s !== 'string') throw new TypeError('amount must be a decimal string');
  const m = /^([+-]?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(s.trim());
  if (!m) throw new Error('invalid decimal: ' + s);
  const digits = (m[2] + (m[3] || '')).replace(/^0+(?=\d)/, '') || '0';
  let scale = (m[3] || '').length;
  let v = BigInt(digits);
  if (m[4]) {
    const e = parseInt(m[4], 10);
    if (e >= 0) v *= 10n ** BigInt(e);
    else scale += -e;
  }
  if (m[1] === '-') v = -v;
  return { v, scale };
}

// Convert to integer cents; requires the value to be exact at 2dp.
function toCents(s) {
  const { v, scale } = parseDecimal(s);
  let n = v;
  if (scale <= 2) n = v * 10n ** BigInt(2 - scale);
  else {
    const d = 10n ** BigInt(scale - 2);
    if (n % d !== 0n) throw new Error('amount has more than 2 decimal places: ' + s);
    n = n / d;
  }
  return n;
}

function fromCents(c) {
  const neg = c < 0n;
  const a = neg ? -c : c;
  return (neg ? '-' : '') + (a / 100n).toString() + '.' + String(a % 100n).padStart(2, '0');
}

function add(a, b) { return fromCents(toCents(a) + toCents(b)); }
function sub(a, b) { return fromCents(toCents(a) - toCents(b)); }

// mul(amount, k): exact product, rounded half-up on absolute value to cents.
function mul(amount, k) {
  if (typeof k !== 'number' && typeof k !== 'string') throw new TypeError('k must be a number or numeric string');
  const a = parseDecimal(amount);
  const kk = parseDecimal(k);
  // product = a.v * kk.v / 10^(a.scale + kk.scale); we want cents: *100.
  // cents = num / den
  let num = a.v * kk.v;
  let scale = a.scale + kk.scale;
  if (scale >= 2) scale -= 2; else num = num * 10n ** BigInt(2 - scale);
  const den = 10n ** BigInt(scale);
  const neg = num < 0n;
  const abs = neg ? -num : num;
  const q = abs / den;
  const r = abs % den;
  const rounded = (r * 2n >= den) ? q + 1n : q; // half-up on absolute value
  return fromCents(neg ? -rounded : rounded);
}

// allocate(total, weights): split into cents by floor of exact rate, then hand
// the remaining cents one each in descending-weight order (ties by index).
function allocate(total, weights) {
  if (!Array.isArray(weights) || weights.length === 0) throw new TypeError('weights must be a non-empty array');
  for (const w of weights) {
    if (!Number.isInteger(w) || w < 0) throw new TypeError('weights must be non-negative integers');
  }
  const sumW = weights.reduce((s, w) => s + w, 0);
  if (sumW <= 0) throw new Error('at least one weight must be positive');
  const cents = toCents(total);
  if (cents < 0n) throw new Error('total must be non-negative');
  const totalNum = Number(cents);

  const result = weights.map(w => Math.floor((totalNum * w) / sumW));
  let remainder = totalNum - result.reduce((s, v) => s + v, 0);
  const order = weights.map((w, i) => ({ w, i })).sort((x, y) => (y.w - x.w) || (x.i - y.i));
  for (const { i } of order) {
    if (remainder <= 0) break;
    result[i] += 1;
    remainder--;
  }
  return result.map(c => fromCents(BigInt(c)));
}

module.exports = { add, sub, mul, allocate };
