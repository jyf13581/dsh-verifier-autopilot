'use strict';
const assert = require('node:assert');
const { add, sub, mul, allocate } = require('./money');

// Acceptance samples
assert.strictEqual(add('0.1', '0.2'), '0.30');
assert.strictEqual(mul('0.105', '1'), '0.11');
assert.deepStrictEqual(allocate('0.05', [1, 1, 1]), ['0.02', '0.02', '0.01']);
assert.deepStrictEqual(allocate('1.00', [1, 1, 1]), ['0.34', '0.33', '0.33']);

// Extra checks
assert.strictEqual(sub('1.00', '0.01'), '0.99');
assert.strictEqual(sub('0.30', '0.10'), '0.20');
assert.strictEqual(add('2.5', '0.05'), '2.55');
assert.strictEqual(mul('0.105', '1'), '0.11');
assert.strictEqual(mul('-0.105', '1'), '-0.11');
assert.strictEqual(mul('10.00', '0.5'), '5.00');
assert.strictEqual(mul('3.33', '3'), '9.99');
assert.strictEqual(sub('0.5', '1'), '-0.50');

// allocate invariants
for (const [t, w] of [['10.00', [1, 2, 3]], ['0.03', [1, 1]], ['5.00', [0, 1, 0]], ['7.77', [2, 2, 1, 1]]]) {
  const parts = allocate(t, w);
  assert.strictEqual(parts.length, w.length);
  const sum = parts.reduce((s, p) => add(s, p), '0.00');
  assert.strictEqual(sum, add(t, '0'));
}

console.log('ALL TESTS PASSED');
console.log('add("0.1","0.2")           =>', add('0.1', '0.2'));
console.log('mul("0.105","1")           =>', mul('0.105', '1'));
console.log('allocate("0.05",[1,1,1])   =>', JSON.stringify(allocate('0.05', [1, 1, 1])));
console.log('allocate("1.00",[1,1,1])   =>', JSON.stringify(allocate('1.00', [1, 1, 1])));
