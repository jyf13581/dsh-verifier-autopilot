/**
 * Clamp a numeric value to the 0-100 percent range.
 *
 * - values below 0   -> 0
 * - values above 100 -> 100
 * - otherwise        -> the numeric input itself
 *
 * @param {number} value - the numeric value to clamp
 * @returns {number} the clamped percent
 */
export function clampPercent(value) {
  if (value < 0) {
    return 0;
  }
  if (value > 100) {
    return 100;
  }
  return value;
}
