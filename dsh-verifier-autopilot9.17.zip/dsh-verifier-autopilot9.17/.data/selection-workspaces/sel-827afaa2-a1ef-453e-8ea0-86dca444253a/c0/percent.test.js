import { test } from 'node:test';
import assert from 'node:assert/strict';

import { clampPercent } from './percent.js';

test('clampPercent: below-range values clamp to 0', () => {
  assert.equal(clampPercent(-1), 0);
  assert.equal(clampPercent(-0.001), 0);
  assert.equal(clampPercent(-100), 0);
  assert.equal(clampPercent(Number.NEGATIVE_INFINITY), 0);
});

test('clampPercent: in-range values pass through unchanged', () => {
  assert.equal(clampPercent(0), 0);
  assert.equal(clampPercent(1), 1);
  assert.equal(clampPercent(42.5), 42.5);
  assert.equal(clampPercent(99.999), 99.999);
  assert.equal(clampPercent(100), 100);
});

test('clampPercent: above-range values clamp to 100', () => {
  assert.equal(clampPercent(100.001), 100);
  assert.equal(clampPercent(101), 100);
  assert.equal(clampPercent(1000), 100);
  assert.equal(clampPercent(Number.POSITIVE_INFINITY), 100);
});
