#!/usr/bin/env node
// 用法: node tally.js <n>  -- 从 stdin 读入文本，输出词频最高的前 n 个单词
import fs from 'node:fs';
const text = fs.readFileSync(0, 'utf8');
const n = Number(process.argv[2] || 10);
const words = text.toLowerCase().match(/[a-z]+/g) || [];
const counts = {};
for (const w of words) counts[w] = (counts[w] || 0) + 1;
const items = Object.entries(counts).sort((a, b) =>
  b[1] - a[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
for (const [w, c] of items.slice(0, n)) console.log(w + ' ' + c);
