import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const tally = path.join(path.dirname(fileURLToPath(import.meta.url)), 'tally.js');

function run(input, n) {
  const args = [tally];
  if (n !== undefined) args.push(String(n));
  return execFileSync(process.execPath, args, { input, encoding: 'utf8' });
}

let failures = 0;
function check(name, actual, expected) {
  const ok = actual === expected;
  if (!ok) failures++;
  console.log((ok ? 'PASS' : 'FAIL') + '  ' + name);
  if (!ok) console.log('  expected: ' + JSON.stringify(expected) + '\n  actual:   ' + JSON.stringify(actual));
}

check('验收样例',
  run('The cat sat. The CAT sat on the mat; the DOG ran.', 3),
  'the 4\ncat 2\nsat 2\n');
check('大小写归并', run('Apple APPLE apple', 5), 'apple 3\n');
check('并列词典序', run('banana apple cherry', 10), 'apple 1\nbanana 1\ncherry 1\n');
check('空输入', run('', 5), '');
check('n 大于词数', run('one two', 100), 'one 1\ntwo 1\n');
check('默认 n=10', run('a b c d e f g h i j k', undefined), 'a 1\nb 1\nc 1\nd 1\ne 1\nf 1\ng 1\nh 1\ni 1\nj 1\n');
check('分隔符', run('abc123def_x!y?z', 10), 'abc 1\ndef 1\nx 1\ny 1\nz 1\n');
check('格式', run('Hi hi', 1), 'hi 2\n');

process.exit(failures ? 1 : 0);
