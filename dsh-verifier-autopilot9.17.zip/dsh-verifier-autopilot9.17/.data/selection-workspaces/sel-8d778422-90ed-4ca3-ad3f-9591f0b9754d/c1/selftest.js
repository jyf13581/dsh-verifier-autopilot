'use strict';

/**
 * selftest.js — money.js 真实验证
 * 运行：node selftest.js
 */

const assert = require('assert');
const { add, sub, mul, allocate } = require('./money');

let passed = 0;
let failed = 0;

function check(label, actual, expected) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) {
    console.log('  ✓ ' + label + '  => ' + a);
    passed++;
  } else {
    console.log('  ✗ ' + label + '  => got ' + a + ', expected ' + e);
    failed++;
  }
}

console.log('=== money.js selftest ===\n');

// ── 验收样例 ──────────────────────────────────────────────

console.log('[验收样例]');
check('add("0.1","0.2") === "0.30"', add('0.1', '0.2'), '0.30');
check('mul("0.105","1") === "0.11"', mul('0.105', '1'), '0.11');
check('allocate("0.05",[1,1,1]) deep === ["0.02","0.02","0.01"]', allocate('0.05', [1, 1, 1]), ['0.02', '0.02', '0.01']);
check('allocate("1.00",[1,1,1]) deep === ["0.34","0.33","0.33"]', allocate('1.00', [1, 1, 1]), ['0.34', '0.33', '0.33']);

// ── add ──────────────────────────────────────────────────

console.log('\n[add]');
check('add("0","0") === "0.00"', add('0', '0'), '0.00');
check('add("1","2") === "3.00"', add('1', '2'), '3.00');
check('add("12.34","56.78") === "69.12"', add('12.34', '56.78'), '69.12');
check('add("0.99","0.01") === "1.00"', add('0.99', '0.01'), '1.00');
check('add("100.00","0.05") === "100.05"', add('100.00', '0.05'), '100.05');
check('add("-1.00","1.00") === "0.00"', add('-1.00', '1.00'), '0.00');
check('add("999999.99","0.01") === "1000000.00"', add('999999.99', '0.01'), '1000000.00');

// ── sub ──────────────────────────────────────────────────

console.log('\n[sub]');
check('sub("1.00","0.30") === "0.70"', sub('1.00', '0.30'), '0.70');
check('sub("0.30","0.30") === "0.00"', sub('0.30', '0.30'), '0.00');
check('sub("0.10","0.20") === "-0.10"', sub('0.10', '0.20'), '-0.10');
check('sub("100.00","33.33") === "66.67"', sub('100.00', '33.33'), '66.67');

// ── mul ──────────────────────────────────────────────────

console.log('\n[mul]');
check('mul("0.105","1") === "0.11" (round half up)', mul('0.105', '1'), '0.11');
check('mul("0.104","1") === "0.10" (round down)', mul('0.104', '1'), '0.10');
check('mul("-0.105","1") === "-0.11" (neg round abs)', mul('-0.105', '1'), '-0.11');
check('mul("10.00","3") === "30.00"', mul('10.00', '3'), '30.00');
check('mul("0.33","3") === "0.99"', mul('0.33', '3'), '0.99');
check('mul("0.333","3") === "1.00" (0.999 rounds to 1.00)', mul('0.333', '3'), '1.00');
check('mul("0.01","0.5") === "0.01" (0.005 rounds up)', mul('0.01', '0.5'), '0.01');
check('mul("0.02","0.5") === "0.01"', mul('0.02', '0.5'), '0.01');
check('mul("0.03","0.5") === "0.02" (0.015 rounds up)', mul('0.03', '0.5'), '0.02');
check('mul("123.45","100") === "12345.00"', mul('123.45', '100'), '12345.00');
check('mul("0","1") === "0.00"', mul('0', '1'), '0.00');
check('mul("-1.00","2") === "-2.00"', mul('-1.00', '2'), '-2.00');

// ── allocate ─────────────────────────────────────────────

console.log('\n[allocate]');
check('allocate("0.05",[1,1,1])', allocate('0.05', [1, 1, 1]), ['0.02', '0.02', '0.01']);
check('allocate("1.00",[1,1,1])', allocate('1.00', [1, 1, 1]), ['0.34', '0.33', '0.33']);
check('allocate("0.03",[1,1,1])', allocate('0.03', [1, 1, 1]), ['0.01', '0.01', '0.01']);
check('allocate("0.00",[1,2,3])', allocate('0.00', [1, 2, 3]), ['0.00', '0.00', '0.00']);
check('allocate("100.00",[1,2,3])', allocate('100.00', [1, 2, 3]), ['16.66', '33.33', '50.01']);
check('allocate("100.00",[3,2,1])', allocate('100.00', [3, 2, 1]), ['50.01', '33.33', '16.66']);
check('allocate("100.00",[1,1,1,1])', allocate('100.00', [1, 1, 1, 1]), ['25.00', '25.00', '25.00', '25.00']);
check('allocate("99.99",[1,1,1])', allocate('99.99', [1, 1, 1]), ['33.33', '33.33', '33.33']);
check('allocate("10.00",[1,0,0])', allocate('10.00', [1, 0, 0]), ['10.00', '0.00', '0.00']);
check('allocate("0.10",[7,3,2])', allocate('0.10', [7, 3, 2]), ['0.06', '0.03', '0.01']);
check('allocate("1.00",[0,0,1])', allocate('1.00', [0, 0, 1]), ['0.00', '0.00', '1.00']);

// ── allocate 总和精确校验 ──────────────────────────────────

console.log('\n[allocate 总和校验]');
{
  const cases = [
    ['0.05', [1, 1, 1]],
    ['1.00', [1, 1, 1]],
    ['100.00', [1, 2, 3]],
    ['99.99', [7, 3, 2, 1]],
    ['0.10', [3, 3, 3]],
    ['1234.56', [10, 20, 30, 40]],
  ];
  for (const [total, weights] of cases) {
    const parts = allocate(total, weights);
    const sum = parts.reduce((s, p) => s + BigInt(Math.round(parseFloat(p) * 100)), 0n);
    // Use string-based sum to avoid any float
    const sumCents = parts.reduce((s, p) => {
      const neg = p.startsWith('-');
      const abs = neg ? p.slice(1) : p;
      const [ip, dp] = abs.split('.');
      const cents = BigInt((ip || '0') + (dp || '').padEnd(2, '0').slice(0, 2));
      return s + (neg ? -cents : cents);
    }, 0n);
    const totalCents = (() => {
      const neg = total.startsWith('-');
      const abs = neg ? total.slice(1) : total;
      const [ip, dp] = abs.split('.');
      return BigInt((ip || '0') + (dp || '').padEnd(2, '0').slice(0, 2));
    })();
    const label = 'allocate("' + total + '",' + JSON.stringify(weights) + ') sum === total';
    if (sumCents === totalCents) {
      console.log('  ✓ ' + label + '  => sum=' + sumCents + ' total=' + totalCents);
      passed++;
    } else {
      console.log('  ✗ ' + label + '  => sum=' + sumCents + ' total=' + totalCents);
      failed++;
    }
  }
}

// ── 浮点精度回归 ─────────────────────────────────────────

console.log('\n[浮点精度回归]');
check('add("0.1","0.2") === "0.30" (no 0.30000000000000004)', add('0.1', '0.2'), '0.30');
check('add("0.1","0.7") === "0.80"', add('0.1', '0.7'), '0.80');
check('sub("0.3","0.1") === "0.20"', sub('0.3', '0.1'), '0.20');
check('mul("0.1","0.2") === "0.02"', mul('0.1', '0.2'), '0.02');
check('add("0.001","0.002") === "0.00" (rounds to cent)', add('0.001', '0.002'), '0.00');

// ── 错误输入 ──────────────────────────────────────────────

console.log('\n[错误输入]');
try {
  allocate('1.00', [0, 0, 0]);
  console.log('  ✗ allocate("1.00",[0,0,0]) should throw');
  failed++;
} catch (e) {
  console.log('  ✓ allocate("1.00",[0,0,0]) throws: ' + e.message);
  passed++;
}
try {
  allocate('-1.00', [1, 2]);
  console.log('  ✗ allocate("-1.00",[1,2]) should throw');
  failed++;
} catch (e) {
  console.log('  ✓ allocate("-1.00",[1,2]) throws: ' + e.message);
  passed++;
}
try {
  allocate('1.00', []);
  console.log('  ✗ allocate("1.00",[]) should throw');
  failed++;
} catch (e) {
  console.log('  ✓ allocate("1.00",[]) throws: ' + e.message);
  passed++;
}

// ── 结果 ──────────────────────────────────────────────────

console.log('\n=== Results ===');
console.log('Passed: ' + passed);
console.log('Failed: ' + failed);
if (failed > 0) {
  console.error('FAILED');
  process.exit(1);
} else {
  console.log('ALL PASSED');
}
