'use strict';

/**
 * money.js — 精确金额计算库（CommonJS）
 *
 * 金额以十进制字符串表示（如 "12.34"）。内部全部用 BigInt 按整数"分"运算，
 * 绝不产生二进制浮点误差。
 *
 * 导出：add(a,b) / sub(a,b) / mul(a,k) / allocate(total, weights)
 */

// ── 内部工具 ──────────────────────────────────────────────

/**
 * 将十进制字符串解析为 { value: BigInt, scale: number }。
 * value 是去掉小数点后的整数，scale 是小数位数。
 * 例："12.34" → { value: 1234n, scale: 2 }
 *     "0.1"   → { value: 1n,    scale: 1 }
 *     "-0.105"→ { value: -105n, scale: 3 }
 */
function parseDecimal(str) {
  str = String(str).trim();
  let negative = false;
  if (str.startsWith('-')) {
    negative = true;
    str = str.slice(1);
  } else if (str.startsWith('+')) {
    str = str.slice(1);
  }
  let parts = str.split('.');
  let intPart = parts[0] || '0';
  let decPart = parts.length > 1 ? parts.slice(1).join('') : '';
  const digits = intPart + decPart;
  let value = BigInt(digits || '0');
  if (negative) value = -value;
  return { value, scale: decPart.length };
}

/**
 * 将 BigInt value（当前 scale 位小数）四舍五入到 targetScale 位小数。
 * 四舍五入规则：绝对值四舍五入（half-up），然后恢复符号。
 */
function roundToScale(value, scale, targetScale) {
  const reduction = scale - targetScale;
  if (reduction <= 0) {
    // 需要扩位（补零），不需要舍入
    return value * (10n ** BigInt(-reduction));
  }
  const divisor = 10n ** BigInt(reduction);
  const negative = value < 0n;
  const absVal = negative ? -value : value;
  const quotient = absVal / divisor;
  const remainder = absVal % divisor;
  if (remainder * 2n >= divisor) {
    // half-up
    return negative ? -(quotient + 1n) : quotient + 1n;
  }
  return negative ? -quotient : quotient;
}

/**
 * 将金额字符串转换为 BigInt 分（2 位小数），四舍五入到分。
 */
function toCents(str) {
  const { value, scale } = parseDecimal(str);
  if (scale === 2) return value;
  if (scale < 2) return value * (10n ** BigInt(2 - scale));
  return roundToScale(value, scale, 2);
}

/**
 * 将 BigInt 分（2 位小数整数）格式化为字符串，如 1234n → "12.34"。
 */
function formatCents(cents) {
  const negative = cents < 0n;
  const absCents = negative ? -cents : cents;
  const s = absCents.toString().padStart(3, '0');
  const intPart = s.slice(0, -2);
  const decPart = s.slice(-2);
  return (negative ? '-' : '') + intPart + '.' + decPart;
}

// ── 公开 API ──────────────────────────────────────────────

/**
 * add(a, b) — 精确加法，返回两位小数字符串。
 */
function add(a, b) {
  const ca = toCents(a);
  const cb = toCents(b);
  return formatCents(ca + cb);
}

/**
 * sub(a, b) — 精确减法，返回两位小数字符串。
 */
function sub(a, b) {
  const ca = toCents(a);
  const cb = toCents(b);
  return formatCents(ca - cb);
}

/**
 * mul(amount, k) — amount × k，结果四舍五入到分。
 * 负数按绝对值四舍五入后恢复符号：-0.105 → -0.11。
 */
function mul(amount, k) {
  const a = parseDecimal(amount);
  const b = parseDecimal(k);
  const product = a.value * b.value;
  const scale = a.scale + b.scale;
  const cents = roundToScale(product, scale, 2);
  return formatCents(cents);
}

/**
 * allocate(total, weights) — 按整数权重数组分配 total 到分。
 * 先 floor 比例分，剩余的"分"按权重从高到低 +0.01（权重相同按数组下标顺序）。
 * 返回与 weights 等长的字符串数组，总和精确等于 total。
 */
function allocate(total, weights) {
  if (!Array.isArray(weights) || weights.length === 0) {
    throw new Error('allocate: weights must be a non-empty array');
  }
  const T = toCents(total);
  if (T < 0n) throw new Error('allocate: total must be non-negative');

  const wBig = weights.map(w => BigInt(w));
  for (const w of wBig) {
    if (w < 0n) throw new Error('allocate: weights must be non-negative integers');
  }
  const W = wBig.reduce((s, w) => s + w, 0n);
  if (W === 0n) throw new Error('allocate: at least one weight must be positive');

  // 按 floor 比例分配（BigInt 整除向零截断 = floor，因 T/w 非负）
  const bases = wBig.map(w => (T * w) / W);
  const sumBases = bases.reduce((s, v) => s + v, 0n);
  let remainder = T - sumBases;

  // 按权重从高到低排序，权重相同按数组下标顺序
  const order = weights.map((_, i) => i).sort((i, j) => {
    if (weights[j] !== weights[i]) return weights[j] - weights[i]; // 权重降序
    return i - j; // 下标升序
  });

  const result = bases.slice();
  let idx = 0;
  while (remainder > 0n) {
    result[order[idx]] += 1n;
    idx++;
    remainder -= 1n;
  }

  return result.map(c => formatCents(c));
}

module.exports = { add, sub, mul, allocate, parseDecimal, toCents, formatCents };
