'use strict';
const assert = require('assert');
const { add, sub, mul, allocate } = require('./money');

assert.strictEqual(add("0.1", "0.2"), "0.30");
assert.strictEqual(mul("0.105", "1"), "0.11");
assert.deepStrictEqual(allocate("0.05", [1, 1, 1]), ["0.02", "0.02", "0.01"]);
assert.deepStrictEqual(allocate("1.00", [1, 1, 1]), ["0.34", "0.33", "0.33"]);

// extra sanity checks
assert.strictEqual(add("3", "0"), "3.00");
assert.strictEqual(sub("1.00", "0.99"), "0.01");
assert.strictEqual(mul("0.105", "-1"), "-0.11");
assert.strictEqual(mul("-0.105", "1"), "-0.11");
assert.strictEqual(mul("2.00", "0.5"), "1.00");
assert.deepStrictEqual(allocate("0.03", [1, 1, 2]), ["0.01", "0.00", "0.02"]); // higher weight gets the remainder cents first
{
  const parts = allocate("10.00", [1, 2, 3]);
  const sum = parts.reduce((s, p) => add(s, p), "0.00");
  assert.strictEqual(sum, "10.00");
}
console.log('All tests passed.');
console.log('add("0.1","0.2") =', add("0.1", "0.2"));
console.log('mul("0.105","1") =', mul("0.105", "1"));
console.log('allocate("0.05",[1,1,1]) =', JSON.stringify(allocate("0.05", [1, 1, 1])));
console.log('allocate("1.00",[1,1,1]) =', JSON.stringify(allocate("1.00", [1, 1, 1])));
