// money.js - decimal money arithmetic without binary float error
'use strict';

// Parse a decimal string like "12.34" (or number-safe input) into integer cents (BigInt-free: use integer cents).
function toCents(v) {
  if (typeof v === 'number') v = String(v);
  if (typeof v !== 'string') throw new TypeError('amount must be a decimal string');
  const m = v.trim().match(/^([+-])?(\d+)(?:\.(\d+))?$/);
  if (!m) throw new Error('invalid amount: ' + v);
  const sign = m[1] === '-' ? -1 : 1;
  const intPart = m[2];
  const frac = (m[3] || '');
  const cents = BigInt(intPart) * 100n
    + BigInt((frac + '00').slice(0, 2))
    // digits beyond the 2nd decimal kept via micro-adjustment by caller; here we require exact <=2dp or handle via scale
    + 0n;
  // For >2 decimal places we need extra scale; handle separately in mulRound.
  if (frac.length > 2) {
    throw new Error('use mul for >2dp rounding');
  }
  return sign * Number(cents);
}

// Parse decimal string to scaled integer with given decimals.
function toScaled(v, decimals) {
  if (typeof v === 'number') v = String(v);
  const m = v.trim().match(/^([+-])?(\d+)(?:\.(\d+))?$/);
  if (!m) throw new Error('invalid amount: ' + v);
  const sign = m[1] === '-' ? -1n : 1n;
  const frac = (m[3] || '');
  const scaled = BigInt(m[2]) * 10n ** BigInt(decimals)
    + BigInt((frac + '0'.repeat(decimals)).slice(0, decimals));
  return sign * scaled;
}

// Format integer cents as "x.xx" string.
function fmt(cents) {
  const n = typeof cents === 'bigint' ? cents : BigInt(cents);
  const neg = n < 0n;
  const a = neg ? -n : n;
  const s = (neg ? '-' : '') + (a / 100n).toString() + '.' + (a % 100n).toString().padStart(2, '0');
  return s;
}

function add(a, b) {
  return fmt(toScaled(a, 2) + toScaled(b, 2));
}

function sub(a, b) {
  return fmt(toScaled(a, 2) - toScaled(b, 2));
}

// Round half away from zero to cents.
function roundHalfUp(absScaled, scale) {
  // absScaled is at 10^scale, scale>=2; return cents (BigInt)
  const unit = 10n ** BigInt(scale - 2);
  const q = absScaled / unit;
  const r = absScaled % unit;
  return r * 2n >= unit ? q + 1n : q;
}

function mul(a, k) {
  if (typeof k === 'string') k = Number(k);
  // Use enough scale: parse a exactly, multiply by k as rational via string.
  const ks = (typeof k === 'number') ? String(k) : String(k);
  const km = ks.match(/^([+-])?(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
  if (!km) throw new Error('invalid multiplier: ' + ks);
  // Represent k as integer * 10^-kdec
  let kfrac = km[3] || '';
  let kexp = km[4] ? parseInt(km[4], 10) : 0;
  let kint = BigInt(km[2] + kfrac);
  let kdec = kfrac.length - kexp;
  const kneg = km[1] === '-';

  const aScaled = toScaled(a, 6); // 6 extra decimals of a
  let num = aScaled * kint;
  let neg = num < 0n;
  if (neg) num = -num;
  let scale = 6 + kdec;
  if (kneg) neg = !neg;
  // If kdec could be negative (large positive exponent), multiply back
  if (scale < 0) { num *= 10n ** BigInt(-scale); scale = 0; }
  const cents = roundHalfUp(num, scale);
  return fmt(neg ? -cents : cents);
}

function allocate(total, weights) {
  if (!Array.isArray(weights) || weights.length === 0) throw new Error('weights must be a non-empty array');
  for (const w of weights) {
    if (!Number.isInteger(w) || w < 0) throw new Error('weights must be non-negative integers');
  }
  const totalCents = toScaled(total, 2);
  if (totalCents < 0n) throw new Error('total must be non-negative');
  const wsum = weights.reduce((s, w) => s + BigInt(w), 0n);
  if (wsum === 0n) throw new Error('at least one weight must be positive');

  const n = weights.length;
  const shares = new Array(n);
  let assigned = 0n;
  for (let i = 0; i < n; i++) {
    shares[i] = (totalCents * BigInt(weights[i])) / wsum; // floor
    assigned += shares[i];
  }
  let remainder = totalCents - assigned;
  // Distribute remaining cents: by descending weight, ties by index order.
  const order = weights.map((w, i) => i).sort((x, y) => weights[y] - weights[x] || x - y);
  let j = 0;
  while (remainder > 0n) {
    const i = order[j % n];
    if (weights[i] > 0) { shares[i] += 1n; remainder -= 1n; }
    j++;
  }
  return shares.map(fmt);
}

module.exports = { add, sub, mul, allocate };
