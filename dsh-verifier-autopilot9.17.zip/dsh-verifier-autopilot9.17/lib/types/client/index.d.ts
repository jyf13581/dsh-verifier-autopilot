type SlotsService = {
    inject(name: string, callback: () => void | (() => void)): void;
    register(options: any, component: any): () => void;
};
type SettingsValue = {
    enabled?: boolean;
    autoFeedback?: boolean;
    model?: string;
    selectionMode?: 'off' | 'auto' | 'always';
    selectionModelStrategy?: 'quality-first' | 'exploration';
};
type SettingsScope = {
    getSnapshot(): {
        value?: SettingsValue;
        status?: string;
    };
    subscribe(listener: () => void): () => void;
    set(field: string, value: unknown): Promise<void>;
};
type SettingsBinder = {
    bind(spec: {
        namespace: string;
    }): SettingsScope;
};
type ClientContext = {
    slots: SlotsService;
    get(name: string): unknown;
    settingsScope?: SettingsBinder;
};
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
export {};
