/**
 * Candidate-model liveness probing (ruling 6.4.4 todo / B-3 defense).
 *
 * `listModels()` only lists the provider catalog; a catalog-listed model can
 * be dead for days (kimi-k3 0/11 window, 2026-09-03/04). quality-first then
 * slots every candidate onto the dead first entry and the whole selection
 * burns down. This prober performs one tiny real request per model and caches
 * the verdict, so liveness — not directory membership — decides the pool.
 *
 * Pure module: fetch/clock are injected for offline tests.
 */
export interface ProbeVerdict {
    ok: boolean;
    at: number;
    detail?: string;
}
export interface ModelProberOptions {
    baseURL: string;
    /** Resolved API key value (never logged). */
    apiKey: string;
    fetchImpl?: typeof fetch;
    now?: () => number;
    /** Per-request timeout for the probe call (default 10s). */
    probeTimeoutMs?: number;
    /** How long a dead verdict is trusted before one retry (default 120s). */
    deadCooldownMs?: number;
}
export interface ModelProber {
    /** true = model answered; false = timeout / HTTP failure. Results are
     *  cached: an ok verdict lasts until reload, a dead verdict cools off. */
    probe(model: string): Promise<boolean>;
    /** Force a model into the dead window (e.g. after a rollout failure). */
    markDead(model: string, detail?: string): void;
    snapshot(): Record<string, ProbeVerdict>;
}
export declare function createModelProber(options: ModelProberOptions): ModelProber;
