/**
 * Candidate batch orchestrator (HANDOFF §2): N real agent rollouts in
 * isolated workspaces, objective-check elimination, verifier select(), and the
 * winner/loser lifecycle. Pure orchestration — the DSH runtime, the process
 * workspace manager, and the Python bridge are injected, so this module is
 * exercised offline with fakes and never depends on a live host here.
 *
 * Invariants:
 * - The runner returns the winner handle/workspace to the Host; every loser is
 *   disposed and removed. Manual/autopilot winner ownership differs (HANDOFF §2.5).
 * - Abort/dispose runs best-effort cleanup for every child, workspace, and
 *   bridge request; persisted historical roots are documented in HANDOFF §6.3.
 * - The winner index maps back to the ORIGINAL candidate index, not the
 *   survivor-subset index.
 */
import { type TrajectoryEvent } from './trajectory.js';
import { type CheckResult, type ObjectiveCheck } from './checks.js';
export type { CheckResult, ObjectiveCheck } from './checks.js';
import { type BridgeProgressRequest, type BridgeProgressResult, type BridgeSelectRequest, type BridgeSelectResult, type BridgeUsage } from './bridge.js';
import { type RetrySleep } from './retry.js';
export type CandidateStatus = 'created' | 'running' | 'finished' | 'failed' | 'eliminated' | 'winner' | 'retained' | 'loser';
/** Objective workspace-diff evidence collected after the rollout (ruling
 *  I.5/J.4). Produced by an injected helper so this module stays pure. */
export interface DiffStatLite {
    files: number;
    insertions: number;
    deletions: number;
    untracked: number;
    fingerprint: string;
}
export interface CandidateRecord {
    index: number;
    sessionId: string | null;
    workspace: string;
    status: CandidateStatus;
    /** Effective route this candidate ran on (heterogeneous pools only). */
    agentOptions?: {
        provider?: string;
        model?: string;
    };
    error?: string;
    eventCount?: number;
    toolCalls?: number;
    /** Execution-class tool calls (meta/discovery tools excluded, ruling K.4-1). */
    execToolCalls?: number;
    /** Worktree diff vs source HEAD; null when the workspace is not git. */
    diffStat?: DiffStatLite | null;
    /** Objective-evidence tier: pass = caller checks all ok; none = no checks,
     *  checks invalid, or never ran. A candidate eliminated by a genuine check
     *  failure is recorded via eliminatedBy instead. */
    objectiveEvidence?: 'pass' | 'none';
    /** Every failing check was a shell interpreter error (B-10): the gate itself
     *  malfunctioned, so the candidate survives as if no checks were given. */
    checksInvalid?: boolean;
    trajectoryChars?: number;
    checks?: CheckResult[];
    eliminatedBy?: string[];
    /** Online progress samples when progressGuard was active. */
    progress?: Array<{
        at: number;
        score: number;
    }>;
}
/** Ruling I.2 outcome state machine: exactly one value once the selection
 *  settles. `winnerBasis` is narrowed for compatibility; consumers must read
 *  `outcome` first. */
export type SelectionOutcome = 'ranked_winner' | 'objective_only_result' | 'single_candidate_fallback' | 'insufficient_evidence' | 'abstain' | 'verifier_unavailable';
export interface SelectionRecord {
    selectionId: string;
    sourceSessionId: string | null;
    startedAt: number;
    finishedAt: number | null;
    status: 'running' | 'completed' | 'failed' | 'aborted';
    error?: string;
    trigger?: 'manual' | 'autopilot';
    stage?: 'workspace' | 'preflight' | 'rollout' | 'checks' | 'ranking' | 'settled';
    policy?: {
        depth: 'standard' | 'deep';
        modelStrategy?: 'quality-first' | 'exploration';
        candidateCount: number;
        nEvaluations: number;
        contextChars: number;
        models: string[];
        pivots?: number;
        verifierEffort?: string;
        taskKind?: string;
        probes?: Record<string, boolean>;
    };
    /** Admission-time task type evidence lane (ruling I.3). */
    taskKind?: string;
    outcome?: SelectionOutcome;
    effectiveEvaluations?: number;
    verificationPasses?: number;
    candidates: CandidateRecord[];
    /** Set ONLY for outcome=ranked_winner: a verifier preference cleared the
     *  margin gate. Retained workspace/handle for the finalizer. */
    winner?: {
        index: number;
        sessionId: string | null;
        workspace: string;
        discardedAt?: number;
    };
    /** Retained survivor that is NOT a chosen-best claim: single-survivor or
     *  objective-only / deduped results keep the workspace under this field. */
    fallback?: {
        index: number;
        sessionId: string | null;
        workspace: string;
        discardedAt?: number;
    };
    finalists?: Array<{
        index: number;
        score: number | null;
        model?: string;
        handoff: string;
    }>;
    /** Per ORIGINAL candidate index; null for candidates that never reached select(). */
    scores?: Array<number | null>;
    /** Original candidate indices, best-first. */
    ranking?: number[];
    nComparisons?: number;
    /** Number of verifier tournament attempts (1 normally, >1 after transient provider failures). */
    rankingAttempts?: number;
    /** Sanitized transient failures that were retried before settlement. */
    rankingRetryErrors?: string[];
    /** Legacy compatibility basis; the authoritative state is `outcome`. */
    winnerBasis?: 'verifier' | 'objective-check-only' | 'single-candidate';
    /** All survivors shared one diff fingerprint — deduped before the verifier
     *  (ruling F3); the record is a fallback, never a ranking claim. */
    noSearchSpace?: boolean;
    /** No candidate carried deterministic objective evidence (checks pass); any
     *  ranking on this record was LLM-only. */
    llmOnly?: boolean;
    /** Top-2 score margin and the gate it was judged against. */
    margin?: number;
    marginThreshold?: number;
    marginCondition?: string;
    /** Threshold is provisional until the calibration experiment (ruling I.4). */
    marginProvisional?: boolean;
    /** At least one candidate's checks were shell-level failures (B-10). */
    checksUnreliable?: boolean;
    /** Effective config captured at start; survives config reloads (ruling F5). */
    configSnapshot?: Record<string, unknown>;
    sourceModel?: string | null;
    sourceHeadAtStart?: string | null;
    /** Free-text note carrying an abstain/fallback reason for the ledger. */
    note?: string;
    /**
     * Source-integration post-audit (ruling G-4/I.5): executed at autopilot
     * winner/fallback cleanup time. `delivered` is granted only when the audit
     * observed integration evidence; un-audited stays `unknown` forever.
     */
    delivery?: {
        audited: boolean;
        headBefore?: string | null;
        headAfter?: string | null;
        headChanged?: boolean | null;
        dirtyEntries?: number | null;
        /** Exit code of the configured post-audit test command, when it ran. */
        postAuditTestExit?: number | null;
        delivered: 'yes' | 'no' | 'unknown';
        note?: string;
    };
    /** Lifecycle timestamps so relay/idle/discard timing questions (B-9) can be
     *  answered from the ledger instead of guessed. */
    timing?: {
        relayedAt?: number;
        auditedAt?: number;
    };
    usage?: BridgeUsage;
    /** Count of criteria sent to the verifier for this ranking. Together with
     *  nComparisons and effectiveEvaluations it pins the scheduler identity
     *  (upstream fine_grained_reward: one API call per directed comparison per
     *  (criterion, rep), no internal retries — on_error='raise' aborts):
     *  usage.calls == nComparisons * criteriaCount * effectiveEvaluations. */
    criteriaCount?: number;
    /** nComparisons * criteriaCount * effectiveEvaluations at ranking time.
     *  A live usage.calls that deviates from this value is itself an anomaly
     *  (legacy tie-swallow path, upstream scheduler change, or counter drift). */
    expectedVerifierCalls?: number;
    verifierModel?: string;
}
export interface SelectionAgentHandle {
    agent: {
        id: string;
        session: {
            events: readonly TrajectoryEvent[];
        };
        followup(message: {
            id: string;
            role: 'user';
            content: Array<{
                type: 'text';
                text: string;
            }>;
            source: {
                kind: 'user';
            };
        }): void | Promise<void>;
        whenIdle(): Promise<void>;
        cancel?: () => void;
    };
    dispose(): Promise<void>;
}
export interface CandidateSpec {
    sessionId: string;
    cwd: string;
    parentSession?: string;
    seed?: readonly TrajectoryEvent[];
    seedLength?: number;
    agentPreset?: string;
    /** Per-candidate route override (already merged over shared defaults). */
    agentOptions?: {
        provider?: string;
        model?: string;
    };
}
/** Online hopeless-rollout abandonment via the library's progress tracker
 *  (HANDOFF §2.3). Only active when progressGuard is provided AND the bridge
 *  implementation offers progress(). Opt-in: absent = no monitoring. */
export interface ProgressGuardOptions {
    /** Sampling interval, ms (default 60000). */
    intervalMs?: number;
    /** Score below this counts as hopeless (default 0.15). */
    minScore?: number;
    /** Consecutive hopeless samples with no new tool evidence before cancel (default 3). */
    graceChecks?: number;
    /** Give up monitoring after this many samples even when healthy (default 8). */
    maxChecks?: number;
}
export interface CandidateFactory {
    create(spec: CandidateSpec): Promise<SelectionAgentHandle>;
}
export interface WorkspaceManager {
    prepare(sel: {
        selectionId: string;
        index: number;
        sourceCwd?: string;
        strictSnapshot?: boolean;
    }): Promise<string>;
    remove(path: string): Promise<void>;
    /** Best-effort purge of the candidate's DSH session-store record (the
     *  persisted journal under the session root). Without this the GUI forever
     *  lists disposed losers as dead sessions pointing at deleted workspaces
     *  (the "目录损坏" ghosts counted 25 orphaned entries on 2026-08-30). */
    purgeSessionRecord?(candidateWorkspace: string): Promise<void>;
}
export interface SelectionRunnerDeps {
    factory: CandidateFactory;
    workspaces: WorkspaceManager;
    bridge: {
        select(req: BridgeSelectRequest): Promise<BridgeSelectResult>;
        progress?(req: BridgeProgressRequest): Promise<BridgeProgressResult>;
    };
    /** Optional provider readiness gate, awaited before ANY candidate spend
     *  (HANDOFF: unsupported provider must fail the selection fast, never mint
     *  five silent ties). Throwing fails the run as status 'failed'. */
    preflight?: (signal: AbortSignal | undefined) => Promise<void>;
    /** Objective diff evidence collector; absent → diff portion of the has-work
     *  gate silently unavailable (tool-call evidence still applies). */
    diffStat?: (cwd: string) => Promise<DiffStatLite | null>;
    /** Full patch capture for the audit pack (ruling I.5). Runs right after the
     *  per-candidate accounting pass, before any workspace disposal. */
    diffFull?: (cwd: string) => Promise<{
        patch: string;
        truncated: boolean;
        untrackedFiles: string[];
    } | null>;
    /** Test seam for bounded verifier backoff; production uses abort-aware timers. */
    sleep?: RetrySleep;
    now?: () => number;
}
export interface SelectionRunInput {
    problem: string;
    candidateCount: number;
    workspaceRoot: string;
    sourceSessionId?: string;
    sourceCwd?: string;
    /** Autopilot requires an exact current-worktree snapshot; manual diagnostics may still use a blank non-git workspace. */
    strictWorkspaceSnapshot?: boolean;
    agentPreset?: string;
    /** Balanced completed-turn prefix inherited by every candidate. */
    seed?: readonly TrajectoryEvent[];
    checks?: readonly ObjectiveCheck[];
    criteria: BridgeSelectRequest['criteria'];
    groundTruthNote?: string | null;
    nEvaluations?: number;
    pivots?: number;
    /** Per-index route overrides, pre-merged by the caller (host) over the
     *  shared candidateModel/candidateProvider defaults. Enables heterogeneous
     *  candidate pools (effect-evaluation lever, HANDOFF §7.3). */
    candidateOptions?: ReadonlyArray<{
        provider?: string;
        model?: string;
    } | undefined>;
    /** Per-candidate diversity instruction appended after the canonical problem. */
    candidateInstructions?: readonly string[];
    trigger?: 'manual' | 'autopilot';
    policy?: SelectionRecord['policy'];
    /** Task-type evidence lane decided at admission (ruling I.3). Unknown is
     *  treated as code-shaped whenever worktrees are involved. */
    taskKind?: string;
    /** Provisional top-2 margin gate; below it the outcome is abstain, not a
     *  verifier winner (ruling I.1/I.4). Recorded per run with its condition. */
    marginThreshold?: number;
    /** Extra fields merged into the record at creation (config snapshot, source
     *  attribution). Runner-controlled keys always win. */
    recordSeed?: Partial<SelectionRecord>;
    onUpdate?: (record: SelectionRecord) => void;
    /** Opt-in online abandonment (see ProgressGuardOptions). */
    progressGuard?: ProgressGuardOptions;
    /** Tournament seed (providers' RNG boundary), defaults 0. */
    algorithmSeed?: number;
    selectionId?: string;
    candidateTimeoutMs?: number;
    selectTimeoutMs?: number;
    verifier: {
        model: string;
        baseUrl: string;
        apiKey: string;
        apiKeyEnv?: string;
        /** Verifier thinking strength (sidecar DEEPSEEK_EFFORT scope), e.g. 'max'. */
        effort?: string;
        onError?: 'tie' | 'raise';
        maxWorkers?: number | null;
        /** Token-bucket dispatch spacing (ms) inside the tournament sidecar; 0 = off. */
        minIntervalMs?: number;
    };
    signal?: AbortSignal;
}
export interface SelectionRunResult {
    record: SelectionRecord;
    /** Transfer of ownership: the orchestrator never disposes the retained
     *  candidate. Present for a ranked winner OR a fallback survivor. */
    retained?: {
        candidateIndex: number;
        sessionId: string;
        workspace: string;
        handle: SelectionAgentHandle;
    };
    /** Captured before loser workspaces were disposed: rendered trajectories and
     *  full git patches per candidate index. Written to the audit pack
     *  (.data/selection-artifacts/<id>/) by the host at settle time. */
    artifacts?: {
        traces: Array<string | null>;
        diffPatches: Array<{
            patch: string;
            truncated: boolean;
            untrackedFiles: string[];
        } | null>;
    };
}
export declare const MAX_CANDIDATES = 5;
/** Delivery decision for the source-integration post-audit (ruling I.2):
 *  `yes` requires observed integration AND a configured test command that
 *  passed. Without a test command the answer is never yes — the plugin does
 *  not invent evidence. */
export declare function evaluateDelivery(input: {
    audited: boolean;
    headChanged: boolean | null;
    dirtyEntries: number | null;
    testsConfigured: boolean;
    testsExit?: number | null;
}): {
    delivered: 'yes' | 'no' | 'unknown';
    note: string;
};
/** Ruling I.1: provisional margin gate. 2026-09-08 calibration round 1 (C0,
 *  24 reps × 2 seeds, minimax-m3@low, eval/calibration/run.mjs): identical-
 *  candidate noise q95 = 0.0123, max = 0.0135, positional bias ≈ 0, no 0.5
 *  pinning; oracle-separated pairs land at margin 0.31..0.46 with 12/12
 *  correct signs. 0.03 = 2.2× the observed noise ceiling. Stays provisional
 *  until the multi-fixture replication (≥5 fixtures) confirms stability. */
export declare const PROVISIONAL_MARGIN_THRESHOLD = 0.03;
export declare class SelectionRunner {
    private readonly deps;
    private readonly now;
    constructor(deps: SelectionRunnerDeps);
    run(input: SelectionRunInput): Promise<SelectionRunResult>;
    /** Winnerless runs (failed/aborted, or a completed run that never crowned)
     *  leave an empty root behind after per-candidate sweeps; drop it so
     *  .data/selection-workspaces only accumulates retained winners. rmdir is
     *  deliberately non-recursive: a root still holding ANYTHING (e.g. a
     *  winner's workspace kept by design) fails the op and is left untouched. */
    private sweepWinnerlessRoot;
}
