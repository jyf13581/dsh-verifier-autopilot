import { BridgeError } from './bridge.js';
export declare const TRANSIENT_RETRY_DELAYS_MS: readonly [2000, 5000, 10000];
export type RetrySleep = (delayMs: number, signal?: AbortSignal) => Promise<void>;
export interface RetryAttemptContext {
    attempt: number;
    /** Remaining shared budget for this attempt, when a deadline is set. */
    timeoutMs?: number;
    /** Aborts on caller cancellation or shared-deadline expiry. */
    signal: AbortSignal;
}
export type RetryOperation<T> = (context: RetryAttemptContext) => Promise<T>;
export declare function abortableRetrySleep(delayMs: number, signal?: AbortSignal): Promise<void>;
/** Retry only transient bridge failures inside one absolute time budget. */
export declare function retryTransientBridge<T>(operation: RetryOperation<T>, options?: {
    signal?: AbortSignal;
    sleep?: RetrySleep;
    delaysMs?: readonly number[];
    /** Absolute epoch deadline shared by every attempt and backoff. */
    deadlineAt?: number;
    /** Total attempts, including the first. Defaults to two. */
    maxAttempts?: number;
    now?: () => number;
    onAttempt?: (attempt: number) => void;
    onRetry?: (error: BridgeError, attempt: number, delayMs: number) => void;
}): Promise<T>;
