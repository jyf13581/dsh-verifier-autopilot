import type { SelectionRecord } from './candidates.js';
import type { TrajectoryEvent } from './trajectory.js';
export type AutopilotMode = 'off' | 'auto' | 'always';
export type AutopilotDepth = 'standard' | 'deep';
export type CandidateModelStrategy = 'quality-first' | 'exploration';
export interface AutopilotPolicyConfig {
    mode: AutopilotMode;
    provider: string;
    preferredModels: readonly string[];
    /** Omitted by legacy callers; planning defaults to quality-first. */
    modelStrategy?: CandidateModelStrategy;
    standardCandidates: number;
    deepCandidates: number;
    nEvaluations: number;
    candidateTimeoutMs: number;
    selectTimeoutMs: number;
}
export interface AutopilotPlan {
    admitted: boolean;
    reason: string;
    depth?: AutopilotDepth;
    candidateCount?: number;
    nEvaluations?: number;
    modelStrategy?: CandidateModelStrategy;
    candidateOptions?: Array<{
        provider: string;
        model: string;
    }>;
    candidateInstructions?: string[];
    criteria?: Record<string, string>;
    candidateTimeoutMs?: number;
    selectTimeoutMs?: number;
    /** Deterministic task-type evidence lane (ruling I.3), written into policy. */
    taskKind?: TaskKind;
}
export type TaskKind = 'code-change' | 'analysis-text' | 'status-report' | 'unknown';
/** Deterministic admission-time task typing (ruling I.3 rules ①–③). */
export declare function classifyTaskKind(text: string): TaskKind;
export declare function planAutopilotTask(task: string, availableModels: readonly string[], config: AutopilotPolicyConfig): AutopilotPlan;
export declare function buildAutopilotContext(events: readonly TrajectoryEvent[], currentTask: string, maxChars?: number): string;
export declare function boundCandidateHandoff(text: string, maxChars?: number): string;
export declare function selectionSeparation(record: SelectionRecord): {
    label: 'single-survivor' | 'unresolved' | 'leaning' | 'clear';
    margin: number | null;
};
/** Outcome-aware relay text (ruling I.2): the contract the source agent sees
 *  must match what actually happened. A fallback is never framed as a chosen
 *  best, an abstain carries no winner, and insufficient evidence tells the
 *  source to simply do the task itself. */
export declare function buildAutopilotRelay(record: SelectionRecord): string;
