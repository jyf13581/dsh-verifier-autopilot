/**
 * Live adapters for SelectionRunner: real DSH agent creation (the recipe proven
 * by the Phase 0 child smoke) and isolated candidate workspaces (git worktree
 * when the source cwd is a git worktree, else a fresh directory).
 *
 * Pure wiring, no decision logic; unit tests cover SelectionRunner with fakes
 * and this file is typechecked + smoke-tested against the live host.
 */
import type { CandidateFactory, WorkspaceManager } from './candidates.js';
import type { TrajectoryEvent } from './trajectory.js';
interface LiveAgentLike {
    id: string;
    ctx: unknown;
    session: {
        events: readonly TrajectoryEvent[];
    };
}
interface LiveContext {
    agents: {
        create(options: Record<string, unknown>): Promise<{
            agent: unknown;
            dispose(): Promise<void>;
        }>;
    };
}
/** Resolve the one repository a direct task explicitly targets. A non-Git
 * session root such as D:\tools is intentionally never scanned recursively:
 * zero or multiple referenced repositories make autopilot transparently defer
 * to the source agent instead of guessing and snapshotting the wrong tree. */
export declare function resolveAutopilotSourceCwd(task: string, sessionCwd: string | undefined): Promise<string | undefined>;
export declare function makeLiveCandidateFactory(args: {
    ctx: LiveContext;
    parent?: LiveAgentLike;
    agentOptions?: {
        provider?: string;
        model?: string;
        maxTokens?: number;
    };
    agentPreset?: string;
    sandboxMode?: string;
}): CandidateFactory;
/** Faithful port of dsh-session-persistence-jsonl's projectKey: separators and
 *  drive colons collapse to '-', [A-Za-z0-9._-] pass through, everything else is
 *  ~XXXX-escaped; the result is wrapped as --<key>-- and truncated to 251 chars.
 *  The session store roots one directory per workspace under this key. */
export declare function projectStoreKey(cwd: string): string;
export declare class WorkspacePrepareError extends Error {
    readonly workspace: string;
    constructor(message: string, workspace: string);
}
export declare class IsolatedWorkspaceManager implements WorkspaceManager {
    private readonly root;
    private readonly storeRoot;
    private readonly worktrees;
    constructor(root: string, sessionStoreRoot?: string);
    private managedPath;
    private discoverLease;
    private removeLease;
    purgeSessionRecord(candidateWorkspace: string): Promise<void>;
    prepare(sel: {
        selectionId: string;
        index: number;
        sourceCwd?: string;
        strictSnapshot?: boolean;
    }): Promise<string>;
    remove(dir: string): Promise<void>;
}
export interface DiffStatLite {
    /** Tracked files whose worktree bytes differ from HEAD. */
    files: number;
    insertions: number;
    deletions: number;
    /** Untracked (non-ignored) files — candidate NEW artifacts live here. */
    untracked: number;
    /** Stable hash of the diff surface: numstat lines + untracked name:size.
     *  Two candidates with equal fingerprints produced the same diff shape. */
    fingerprint: string;
}
/** Objective work evidence for one candidate workspace (ruling K.5 / J.4).
 *  Returns null when the workspace is not a git worktree (manual blank
 *  workspaces) — the caller then relies on tool-call evidence alone. */
export declare function gitDiffStat(cwd: string): Promise<DiffStatLite | null>;
export interface DiffFull {
    /** git diff HEAD patch text, capped; untracked new files are included via
     *  `git add -N` intent-to-add (safe: runs in a disposable worktree). */
    patch: string;
    truncated: boolean;
    /** Untracked (non-ignored) file names — the typical brand-new deliverable. */
    untrackedFiles: string[];
}
/** Full diff evidence for the audit pack (ruling I.5): what the candidate
 *  actually changed, captured BEFORE the workspace can be reclaimed. */
export declare function gitDiffFull(cwd: string, patchCap?: number): Promise<DiffFull | null>;
export interface RepoState {
    head: string | null;
    /** Uncommitted porcelain entries (tracked edits + untracked). */
    dirtyEntries: number;
}
/** Post-audit evidence for the source repository (ruling I.5/G-4): HEAD
 *  before/after plus worktree dirtiness, never a merge claim. */
export declare function gitRepoState(cwd: string): Promise<RepoState | null>;
export {};
