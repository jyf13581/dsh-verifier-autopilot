/**
 * Objective per-candidate checks: caller-supplied shell commands that run in
 * the candidate's own workspace. A non-zero exit or timeout eliminates the
 * candidate before any verifier comparison — HANDOFF §2.3.
 */
export interface ObjectiveCheck {
    name: string;
    command: string;
    timeoutMs?: number;
}
export interface CheckResult {
    name: string;
    ok: boolean;
    exitCode: number | null;
    durationMs: number;
    /** Bounded tail of combined stdout+stderr, for the record. */
    outputTail: string;
    /** True when the failure output is a shell interpreter/parse error, i.e. the
     *  check command itself never ran (pwsh quoted-argument mangling killed it
     *  before any candidate artifact was examined — sel-5e84f540, ruling B-10).
     *  Such failures must not eliminate a candidate. */
    harnessError?: boolean;
}
/** A failed check whose entire tail is shell-level interpreter noise proves
 *  nothing about the candidate; the check command itself was broken. */
export declare function isHarnessError(outputTail: string): boolean;
export interface RunChecksOptions {
    signal?: AbortSignal;
    defaultTimeoutMs?: number;
    outputTailChars?: number;
    now?: () => number;
}
export declare function runChecks(cwd: string, checks: readonly ObjectiveCheck[], options?: RunChecksOptions): Promise<CheckResult[]>;
