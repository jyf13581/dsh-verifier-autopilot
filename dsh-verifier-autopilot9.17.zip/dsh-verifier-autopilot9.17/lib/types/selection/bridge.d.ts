/**
 * VerifierBridge: Node side of the Python sidecar protocol (bridge/PROTOCOL.md).
 *
 * Owns the child process lifecycle (lazy spawn, respawn on crash, disposal),
 * serial-framed JSONL I/O, per-request timeout, external abort, and error
 * mapping. The API key is injected into the child's environment at spawn and
 * never serialized into a frame. A timeout or mid-flight abort kills the
 * child: the sidecar is serial, so a stuck request poisons the pipe.
 */
export type BridgeErrorCode = 'bad_frame' | 'invalid_request' | 'missing_api_key' | 'client_init' | 'missing_logprobs' | 'timeout' | 'provider_error' | 'selection_failed' | 'preflight_failed' | 'selection_timeout' | 'bridge_timeout' | 'bridge_down' | 'bridge_disposed' | 'bridge_aborted' | 'bridge_protocol';
export declare class BridgeError extends Error {
    readonly code: BridgeErrorCode;
    readonly retriable: boolean;
    constructor(code: BridgeErrorCode, message: string, retriable: boolean);
}
export interface BridgeHealth {
    python: string;
    llm_verifier_version: string;
    select_available: boolean;
    note: string;
    deepseek_effort: string | null;
}
export interface BridgeSelectRequest {
    problem: string;
    candidates: string[];
    criteria: Record<string, string> | Array<{
        id: string;
        name: string;
        description: string;
    }>;
    groundTruthNote?: string | null;
    nEvaluations?: number;
    pivots?: number;
    seed?: number;
    model: string;
    baseUrl: string;
    /** Resolved key VALUE: placed in the child env at spawn, never framed. */
    apiKey: string;
    apiKeyEnv?: string;
    /** Verifier thinking strength ('off' | 'low' | 'high' | 'max'); the sidecar
     *  maps it onto DEEPSEEK_EFFORT for exactly this request. */
    effort?: string;
    onError?: 'tie' | 'raise';
    maxWorkers?: number | null;
    /** Token-bucket dispatch spacing (ms) inside the tournament; 0 = off. */
    minIntervalMs?: number;
    /** Per-call transient (429) retries inside the sidecar. Each retry re-enters
     *  the relay's per-request account round-robin, so a rate-limited account
     *  stalls only its own call. 0..5, default 2. */
    callRetries?: number;
    timeoutMs?: number;
    signal?: AbortSignal;
}
export interface BridgeUsage {
    calls: number;
    input_tokens: number;
    cached_input_tokens: number;
    uncached_input_tokens: number;
    output_tokens: number;
    reasoning_tokens: number;
    cache_hit_rate: number;
}
export interface BridgeSelectResult {
    index: number;
    bestPreview: string;
    scores: number[];
    ranking: number[];
    nComparisons: number;
    criteria: string[];
    usage: BridgeUsage;
}
export interface VerifierBridgeOptions {
    pythonPath: string;
    scriptPath: string;
    /** Extra child env (merged over a copy of process.env). */
    env?: Record<string, string>;
    /** Default per-request timeout; overridden per request. */
    defaultTimeoutMs?: number;
    /** Grace period for the shutdown frame before SIGKILL. */
    shutdownGraceMs?: number;
    /** Cap on retained stderr diagnostics (chars). */
    stderrBufferChars?: number;
}
export interface BridgeProgressRequest {
    problem: string;
    /** Rendered trajectory fragments so far (each entry is one "agent step"). */
    steps: string[];
    model: string;
    baseUrl: string;
    apiKey: string;
    apiKeyEnv?: string;
    nEvaluations?: number;
    /** Verifier thinking strength; same per-request semantics as select. */
    effort?: string;
    timeoutMs?: number;
    signal?: AbortSignal;
}
export interface BridgeProgressResult {
    score: number;
    usage: BridgeUsage;
}
export declare class VerifierBridge {
    private readonly pythonPath;
    private readonly scriptPath;
    private readonly extraEnv;
    private readonly defaultTimeoutMs;
    private readonly shutdownGraceMs;
    private readonly stderrCap;
    private child;
    private stdoutBuf;
    private stderrTail;
    private pending;
    private disposed;
    private spawnKey;
    constructor(options: VerifierBridgeOptions);
    get alive(): boolean;
    private noteStderr;
    private ensureSpawned;
    private stderrSuffix;
    private onStdout;
    private onChildGone;
    private teardownChild;
    private request;
    health(options?: {
        timeoutMs?: number;
    }): Promise<BridgeHealth>;
    select(req: BridgeSelectRequest): Promise<BridgeSelectResult>;
    /** Online progress score (llm_verifier.track, single final checkpoint):
     *  "would the agent's CURRENT state already satisfy the task?" — the
     *  framework's own hopeless-rollout meter (HANDOFF §2.3). */
    progress(req: BridgeProgressRequest): Promise<BridgeProgressResult>;
    /**
     * Provider readiness gate for selection: one tiny directed comparison with a
     * blatantly asymmetric pair. PASS requires a real tournament (nComparisons>0)
     * AND scores[0] > scores[1] — a model that cannot follow the score-tag
     * protocol degenerates to 0.5/0.5 (silent tie), which fails this check the
     * same as a wrong verdict. Raises BridgeError('preflight_failed') on failure.
     */
    preflight(opts: {
        model: string;
        baseUrl: string;
        apiKey: string;
        apiKeyEnv?: string;
        effort?: string;
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<void>;
    private frameError;
    dispose(): Promise<void>;
}
