/**
 * Render one candidate session's durable events into verifier-ready trajectory
 * text. Stands alone from the legacy single-trace verifier rendering: this one
 * covers the whole candidate rollout (optionally starting after a seed prefix)
 * and renders tool evidence with the [E*] line ids a finding can cite.
 */
export interface TrajectoryEvent {
    type: string;
    seq?: number;
    time?: number;
    data?: Record<string, unknown>;
}
export interface TrajectoryRender {
    text: string;
    eventCount: number;
    renderedLines: number;
    toolCalls: number;
    /** Tool calls excluding catalog/meta discovery tools. The winner gate counts
     *  only execution evidence: a candidate whose toolCalls are all tool_search
     *  or tool_slimmer_catalog never touched the workspace (ruling K.4-1). */
    execToolCalls: number;
    truncatedCells: number;
    totalChars: number;
}
export declare function isMetaToolName(name: unknown): boolean;
/**
 * Render events with seq >= fromSeq. Line kinds: USER / ASSISTANT / TOOL CALL /
 * TOOL RESULT. Chunk, policy, inbox, and title events are runtime noise and
 * dropped; turn/step markers are folded into step boundaries.
 */
export declare function renderTrajectory(events: readonly TrajectoryEvent[], options?: {
    fromSeq?: number;
    cellCap?: number;
    totalCap?: number;
}): TrajectoryRender;
