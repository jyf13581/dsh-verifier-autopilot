/**
 * SelectionHost: host-side lifecycle for best-of-N candidate selection
 * (HANDOFF §2.5). Wraps SelectionRunner with live DSH adapters, the
 * verifier bridge singleton, selection history (in-memory + bounded JSONL),
 * and single-active-run admission.
 *
 * Boundary rules honored here:
 * - Selection may be started by the diagnostic HTTP route or by the host's
 *   pre-step autopilot policy; this module itself remains transport-agnostic.
 * - Manual runs may fork a balanced completed-turn seed. Autopilot runs pass a
 *   bounded context packet and disable raw event seeding.
 * - dispose() aborts an in-flight run and disposes every retained winner
 *   handle; no orphan agents, workspaces, or sidecar processes survive.
 */
import { type BridgeSelectRequest, type BridgeSelectResult } from './bridge.js';
import { type CandidateFactory, type ObjectiveCheck, type SelectionRecord, type WorkspaceManager } from './candidates.js';
import type { TrajectoryEvent } from './trajectory.js';
import { type RetrySleep } from './retry.js';
export interface SelectionsAgentProvider {
    list(): Array<{
        id: string;
    }>;
    get(id: string): {
        id: string;
        ctx: unknown;
        session: {
            events: readonly TrajectoryEvent[];
            header?: {
                cwd?: string;
                delegationDepth?: number;
            };
        };
        /** Post a message into the source session (selection settlement notice). */
        followup?: (message: {
            id: string;
            role: 'user';
            content: Array<{
                type: 'text';
                text: string;
            }>;
            source: {
                kind: 'plugin';
                plugin: string;
                form: string;
                summary?: string;
            };
        }) => void | Promise<void>;
    } | undefined;
}
interface LiveAgentsWiring {
    create(options: Record<string, unknown>): Promise<{
        agent: unknown;
        dispose(): Promise<void>;
    }>;
}
export interface SelectionHostDeps {
    agents?: SelectionsAgentProvider;
    liveAgents?: LiveAgentsWiring;
    resolveKey?: (ref: string) => Promise<string | undefined>;
    /** Session default route, used to complete partial candidate route
     *  overrides (DSH requires provider and model as a pair). */
    defaultRoute?: () => {
        provider?: string;
        model?: string;
    } | undefined;
    verifier: () => {
        model: string;
        baseURL: string;
        apiKeyEnv: string;
        effort?: string;
        maxWorkers?: number;
        minIntervalMs?: number;
    };
    /** Host-level default for manual /select when the request omits
     *  candidateTimeoutMs; sourced from config so strong slow models get the
     *  same time budget as autopilot instead of the runner's 300s floor. */
    candidateTimeoutMsDefault?: () => number;
    /** Host-level config defaults for manual /select when the request omits
     *  them. Autopilot always passes its plan explicitly; these defaults let
     *  operator defaults ride every manual run the same way. */
    nEvaluationsDefault?: () => number;
    pivotsDefault?: () => number;
    /** Provisional margin gate for the winner state machine (ruling I.1). */
    marginThresholdDefault?: () => number;
    /** Config default for the selection time budget when /select omits it. */
    selectTimeoutMsDefault?: () => number;
    /** Directory for the per-selection audit pack written BEFORE cleanup
     *  (ruling I.5); null disables persistence. Derived from workspaceRoot. */
    artifactsDir?: string | null;
    pythonPath?: string;
    sidecarPath?: string;
    workspaceRoot?: string;
    selectionsFile?: string | null;
    now?: () => number;
    /** Settlement notice hook: called once per finished selection with the final
     *  record. Wired by the host layer to post the outcome into the SOURCE
     *  session (the operator keeps chatting there; without this the result is
     *  invisible outside the GUI panel). Best-effort; exceptions are contained. */
    notify?: (record: SelectionRecord) => void;
    /** Deterministic overrides for tests: bypass live factory/workspace/bridge. */
    testing?: {
        factory?: CandidateFactory;
        workspaces?: WorkspaceManager;
        bridge?: {
            select(req: BridgeSelectRequest): Promise<BridgeSelectResult>;
        };
        retrySleep?: RetrySleep;
        /** Deterministic diff evidence for gate tests. */
        diffStat?: (cwd: string) => Promise<import('./candidates.js').DiffStatLite | null>;
        /** Patch capture for artifact tests. */
        diffFull?: (cwd: string) => Promise<{
            patch: string;
            truncated: boolean;
            untrackedFiles: string[];
        } | null>;
    };
}
export declare const SELECTION_VERIFIER_MAX_WORKERS = 1;
export declare const AUTO_VERIFIER_WORKERS = 4;
/** Resolve the tournament worker count from config: 0 = auto, 1..16 explicit.
 *  Call-count identity is unaffected (calls = nComparisons × criteriaCount × K);
 *  workers only change wall-clock time and account spread. */
export declare function effectiveVerifierWorkers(explicit: number | undefined | null): number;
export interface StartSelectionBody {
    sourceSessionId?: string;
    problem?: string;
    candidateCount?: number;
    criteria?: BridgeSelectRequest['criteria'];
    /** Opt-in online hopeless-rollout abandonment (HANDOFF §2.3). */
    progressGuard?: unknown;
    groundTruthNote?: string | null;
    checks?: ObjectiveCheck[];
    nEvaluations?: number;
    pivots?: number;
    algorithmSeed?: number;
    agentPreset?: string;
    candidateTimeoutMs?: number;
    selectTimeoutMs?: number;
    candidateModel?: string;
    candidateProvider?: string;
    /** Heterogeneous pool: one entry per candidate; entries fall back to
     *  candidateProvider/candidateModel. When present without candidateCount,
     *  the array length is the candidate count. */
    candidateOptions?: unknown;
    candidateInstructions?: unknown;
    useSourceSeed?: boolean;
    /** Explicit Git source workspace for a manual run. Requires an existing
     *  directory that resolves to a Git root; candidates get isolated
     *  worktrees under it. Without this (and without a source session) a real
     *  run is refused rather than executed in the host process directory. */
    sourceCwd?: string;
    trigger?: 'manual' | 'autopilot';
    policy?: SelectionRecord['policy'];
    /** Task-kind lane decided at admission (autopilot sets policy.taskKind). */
    taskKind?: string;
    /** Override the provisional margin gate for this run (0..0.5). */
    marginThreshold?: number;
}
export declare class SelectionApiError extends Error {
    readonly status: number;
    readonly code: string;
    constructor(status: number, code: string, message: string);
}
export declare const SELECTIONS_HISTORY_LIMIT = 200;
/** Keep every verifier phase on the same finite request budget. */
export declare function normalizeSelectionTimeoutMs(value: unknown, fallback?: number): number;
/** Explicit per-request candidate timeout wins; otherwise the host-level config
 *  default applies; without either the runner keeps its 300s safety floor. */
export declare function normalizeCandidateTimeoutMs(value: unknown, fallback: number | undefined): number | undefined;
export declare function defaultSelectionsFile(): string;
export declare function defaultSidecarPath(): string;
export declare function defaultPythonPath(): string;
export declare function defaultWorkspaceRoot(): string;
/** Cut a balanced completed-turn seed prefix: the log up to and including the
 * LAST turn/end. Seeding is skipped (not guessed) when no completed turn
 * exists or the prefix is too long to carry. */
export declare function cutBalancedSeed(events: readonly TrajectoryEvent[], cap?: number): {
    seed: readonly TrajectoryEvent[];
    seedLength: number;
} | undefined;
/** The problem candidates solve: an explicit body value wins; otherwise the
 * source session's most recent direct user task. Never a synthesized guess. */
export declare function problemFromEvents(events: readonly TrajectoryEvent[]): string | undefined;
/** DSH agent routes come in pairs: a partial {provider}-only or {model}-only
 *  override makes the FIRST candidate turn fail with "no provider/model"（2026-08-28
 *  异质池首跑实测）。Complete the missing half from the session default route;
 *  refuse loudly when no default is available. */
export declare function completeRoutePair(route: {
    provider?: string;
    model?: string;
}, dft: {
    provider?: string;
    model?: string;
} | undefined, label: string): {
    provider?: string;
    model?: string;
} | undefined;
/** Parse + merge the per-candidate route array over the shared defaults. */
export declare function safeCandidateOptions(input: unknown, shared: {
    provider?: string;
    model?: string;
}, dft?: {
    provider?: string;
    model?: string;
}): Array<{
    provider?: string;
    model?: string;
}> | undefined;
export declare class SelectionHost {
    private readonly deps;
    private readonly now;
    private readonly selections;
    private active;
    private readonly winners;
    private bridgeSingleton;
    private workspaceManager;
    private disposed;
    private readonly listeners;
    private readonly selectionsFile;
    constructor(deps: SelectionHostDeps);
    subscribe(listener: () => void): () => void;
    private emit;
    listSelections(): SelectionRecord[];
    getSelection(selectionId: string): SelectionRecord | undefined;
    activeSelectionId(): string | null;
    /** Provider tuples proven ready during this host's lifetime. */
    private readonly preflightOk;
    private bridge;
    /** One tiny asymmetric comparison proves the relay+model can actually
     *  score tags for selection; memoized per (baseURL, model, key env). A
     *  supported failure raises and the runner fails the selection before any
     *  candidate spend. */
    private runVerifierPreflight;
    /** Explicit operator-triggered selection. Throws SelectionApiError for the
     *  route to translate. The run completes asynchronously; the returned record
     *  is the RUNNING placeholder later replaced in place in the history list. */
    start(body: StartSelectionBody, runtime?: {
        sourceCwd?: string;
    }): Promise<SelectionRecord>;
    private finishRun;
    /** Abort the in-flight selection (no-op for finished ones). A record that
     *  already settled answers false even if the active slot is mid-clear, so a
     *  late cancel can never resurrect a terminal run. */
    cancel(selectionId: string): boolean;
    /** Await one selection's durable terminal record. The caller owns cancellation
     *  policy; aborting this wait does not implicitly cancel unrelated runs. */
    waitFor(selectionId: string, signal?: AbortSignal): Promise<SelectionRecord>;
    /** Release the live candidate handle while retaining its persisted session
     *  and workspace. Failed disposal stays retained so a later call can retry. */
    releaseWinner(selectionId: string): Promise<'released' | 'not-retained'>;
    /** Destroy the retained candidate outright (winner OR fallback). Each
     *  operation is idempotent; discardedAt is durable only after handle,
     *  workspace, session journal, and the audit pack have all settled. */
    discardWinner(selectionId: string): Promise<boolean>;
    snapshot(): Record<string, unknown>;
    private loadSelections;
    /** Persist a settled record again after an out-of-band mutation (relay
     *  timestamps, delivery audit): the ledger line wins by recency on reload,
     *  and the audit pack's record.json re-reads from the same object. */
    pubRecord(record: SelectionRecord): void;
    private persist;
    /** Audit pack (ruling I.5/G, F6): one directory per selection, written at
     *  settle BEFORE any workspace cleanup can free the evidence it holds —
     *  record.json plus raw per-candidate materials. discard rewrites only the
     *  record so settlement attribution stays immutable. */
    private artifactDir;
    private writeArtifact;
    dispose(): Promise<void>;
}
export {};
