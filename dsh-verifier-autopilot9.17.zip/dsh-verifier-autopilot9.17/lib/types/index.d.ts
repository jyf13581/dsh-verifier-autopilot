import type { Context } from '@deepseek-ai/cordis';
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import z from 'schemastery';
import { type AggregateResult } from './verifier.js';
import { SelectionHost } from './selection/host.js';
import { type AutopilotMode, type CandidateModelStrategy } from './selection/autopilot.js';
export { VerificationCoordinator } from './coordinator.js';
export { SelectionHost } from './selection/host.js';
export type { SelectionRecord } from './selection/candidates.js';
export type { TurnBounds, ScheduleKind, ScheduleEntry, RunContext, EntryOutcome } from './coordinator.js';
type Credentials = {
    resolve?: (ref: string) => Promise<{
        value?: string;
    } | undefined>;
};
type Agent = {
    id: string;
    session: {
        events: readonly EventRecord[];
        header?: {
            cwd?: string;
            parentSession?: string;
        };
    };
    ctx: Context;
    followup: (message: UserMessage) => void | Promise<void>;
};
type EventRecord = {
    type: string;
    seq?: number;
    time?: number;
    data?: any;
};
type HostContext = Context & {
    webServer: {
        register(route: WebRoute): () => void;
    };
    credentials?: Credentials;
    agents?: {
        list(): Agent[];
        get(id: string): Agent | undefined;
    };
    llm?: {
        listModels(provider: string): Promise<Array<{
            id: string;
            provider?: string;
        }>>;
    };
};
type WebRoute = {
    kind: 'exact';
    path: string;
    handler: (req: any, res: any) => void | Promise<void>;
};
export declare const name = "@dsh-external/dsh-verifier-autopilot";
export declare const inject: string[];
export interface Config {
    enabled: boolean;
    autoFeedback: boolean;
    routes: number;
    scoreThreshold: number;
    disagreementThreshold: number;
    maxFeedbackPerSession: number;
    timeoutMs: number;
    maxTokens: number;
    temperature: number;
    baseURL: string;
    model: string;
    apiKeyEnv: string;
    /** Thinking strength ('思考强度') shared by the five-lane verifier and the
     *  selection tournament verifier: off | low | high | max. 'off' explicitly
     *  disables thinking; anything else enables it at that effort level. */
    verifierEffort: 'off' | 'low' | 'high' | 'max';
    /** Accept well-formed single-letter score tags without token logprobs (degraded mode).
     *  Default false: routes lacking logprob evidence stay invalid. */
    allowLabelFallback: boolean;
    /** Suppress feedback when the median is high AND a majority of valid lanes found no
     *  concrete defect (single-lane outlier noise). Blocked verifications are recorded as
     *  suppressedFeedback on the record instead of disturbing the agent. */
    divergenceGuard: boolean;
    /** Minimum aggregate median for the divergence guard to apply. */
    divergenceGuardMedian: number;
    /** Skip five-lane verification for bare status-continuation turns ("继续"/"next")
     *  that produced no tool evidence; the turn is still recorded with status
     *  'skipped' instead of consuming the session's feedback quota. Default true. */
    skipStatusContinuation: boolean;
    /** Post a one-line settlement notice into the selection's source session so
     *  the outcome is visible where the operator is actually working, without
     *  opening the panel. Plugin-sourced: never counts toward feedback quota,
     *  never seeds candidate tasks, never feeds verifier evidence. */
    selectionNotify: boolean;
    selectionMode: AutopilotMode;
    selectionModelStrategy: CandidateModelStrategy;
    selectionProvider: string;
    selectionModels: string;
    selectionStandardCandidates: number;
    selectionDeepCandidates: number;
    selectionEvaluations: number;
    /** Pivot round iterations (k, O(N·k); clamped to the survivor count). */
    selectionPivots: number;
    selectionCandidateTimeoutMs: number;
    selectionSelectTimeoutMs: number;
    /** Provisional top-2 margin gate for the winner state machine (ruling I.1);
     *  replaced by the calibrated quantile once the I.4 experiment lands. */
    selectionMarginThreshold: number;
    /** Probe candidate models for liveness before planning (default true):
     *  catalog membership is not availability (ruling 6.4 kimi-k3 window). */
    selectionProbeEnabled: boolean;
    /** Optional explicit test command for the integration post-audit. Empty
     *  (default) = the audit never runs user tests, so delivered=yes stays
     *  unreachable — as the ruling demands until the operator opts in. */
    selectionPostAuditTestCommand: string;
    /** Verifier tournament concurrency (server-side ThreadPool workers).
     *  0 = auto (AUTO_VERIFIER_WORKERS=4): the relay's per-request account
     *  round-robin spreads concurrent calls across independent accounts, so one
     *  rate-limited account stalls only its own call. Explicit 1..16 overrides.
     *  Parallelism is capped by the account pool size in practice. */
    selectionVerifierWorkers: number;
    /** Token-bucket smoothing: minimum spacing (ms) between verifier request
     *  dispatches, shared by the five-lane verifier and the tournament sidecar.
     *  0 (default) = off. Spreads self-inflicted rate-limit bursts. */
    verifierMinIntervalMs: number;
    /** Cheap-tier model for mechanical session-verifier lanes (completion /
     *  evidence). Empty (default) = every lane uses `model`. Opt-in layered
     *  model usage: only hard lanes stay on the main verifier model. */
    verifierSmallModel: string;
}
export declare const Config: z<Schemastery.ObjectS<{
    enabled: z<boolean, boolean>;
    autoFeedback: z<boolean, boolean>;
    routes: z<number, number>;
    scoreThreshold: z<number, number>;
    disagreementThreshold: z<number, number>;
    maxFeedbackPerSession: z<number, number>;
    timeoutMs: z<number, number>;
    maxTokens: z<number, number>;
    temperature: z<number, number>;
    baseURL: z<string, string>;
    model: z<string, string>;
    apiKeyEnv: z<string, string>;
    verifierEffort: z<"low" | "high" | "off" | "max", "low" | "high" | "off" | "max">;
    allowLabelFallback: z<boolean, boolean>;
    divergenceGuard: z<boolean, boolean>;
    divergenceGuardMedian: z<number, number>;
    skipStatusContinuation: z<boolean, boolean>;
    selectionNotify: z<boolean, boolean>;
    selectionMode: z<"auto" | "off" | "always", "auto" | "off" | "always">;
    selectionModelStrategy: z<"quality-first" | "exploration", "quality-first" | "exploration">;
    selectionProvider: z<string, string>;
    selectionModels: z<string, string>;
    selectionStandardCandidates: z<number, number>;
    selectionDeepCandidates: z<number, number>;
    selectionEvaluations: z<number, number>;
    selectionPivots: z<number, number>;
    selectionCandidateTimeoutMs: z<number, number>;
    selectionSelectTimeoutMs: z<number, number>;
    selectionMarginThreshold: z<number, number>;
    selectionProbeEnabled: z<boolean, boolean>;
    selectionPostAuditTestCommand: z<string, string>;
    selectionVerifierWorkers: z<number, number>;
    verifierMinIntervalMs: z<number, number>;
    verifierSmallModel: z<string, string>;
}>, Schemastery.ObjectT<{
    enabled: z<boolean, boolean>;
    autoFeedback: z<boolean, boolean>;
    routes: z<number, number>;
    scoreThreshold: z<number, number>;
    disagreementThreshold: z<number, number>;
    maxFeedbackPerSession: z<number, number>;
    timeoutMs: z<number, number>;
    maxTokens: z<number, number>;
    temperature: z<number, number>;
    baseURL: z<string, string>;
    model: z<string, string>;
    apiKeyEnv: z<string, string>;
    verifierEffort: z<"low" | "high" | "off" | "max", "low" | "high" | "off" | "max">;
    allowLabelFallback: z<boolean, boolean>;
    divergenceGuard: z<boolean, boolean>;
    divergenceGuardMedian: z<number, number>;
    skipStatusContinuation: z<boolean, boolean>;
    selectionNotify: z<boolean, boolean>;
    selectionMode: z<"auto" | "off" | "always", "auto" | "off" | "always">;
    selectionModelStrategy: z<"quality-first" | "exploration", "quality-first" | "exploration">;
    selectionProvider: z<string, string>;
    selectionModels: z<string, string>;
    selectionStandardCandidates: z<number, number>;
    selectionDeepCandidates: z<number, number>;
    selectionEvaluations: z<number, number>;
    selectionPivots: z<number, number>;
    selectionCandidateTimeoutMs: z<number, number>;
    selectionSelectTimeoutMs: z<number, number>;
    selectionMarginThreshold: z<number, number>;
    selectionProbeEnabled: z<boolean, boolean>;
    selectionPostAuditTestCommand: z<string, string>;
    selectionVerifierWorkers: z<number, number>;
    verifierMinIntervalMs: z<number, number>;
    verifierSmallModel: z<string, string>;
}>>;
/** Bridge the settings service's source/change callbacks to the live Host config. */
export declare function createSettingsSourceHooks(host: {
    replaceConfig(next: Config): void;
}): {
    setSource(source: () => Config): void;
    onChange(): void;
};
export declare class VerifyAbortedError extends Error {
    constructor();
}
type RecordState = {
    id: string;
    sessionId: string;
    turn: number;
    turnEndSeq: number;
    status: 'running' | 'completed' | 'partial' | 'failed' | 'skipped';
    startedAt: number;
    finishedAt?: number;
    aggregate?: AggregateResult;
    feedbackSent: boolean;
    feedbackError?: string;
    /** set when the divergence guard blocked a would-be feedback trigger */
    suppressedFeedback?: {
        median: number;
        noDefectLanes: number;
        validLanes: number;
    };
    /** Feedback is intentionally withheld when no valid lane supplied an
     * independent tool-result citation for a concrete defect. */
    feedbackSuppressed?: {
        reason: 'no-independent-evidence';
        defectFindings: number;
        independentFindings: number;
    };
    /** set when the turn was classified as pure no-op noise and verification was skipped */
    skippedReason?: string;
    /** aggregated [E*] citation audit over valid lanes' findings */
    citationAudit?: {
        defectFindings: number;
        defectFindingsWithoutCitation: number;
        findingsCitingUnknownIds: number;
        findingsCitingHistoricalVerdict: number;
        findingsWithoutIndependentCitation: number;
    };
    traceStats?: {
        eventCount: number;
        renderedEventCount: number;
        toolEventCount: number;
        traceChars: number;
        evidenceSignalCount: number;
        passSignalCount: number;
        evidenceSummaryChars: number;
    };
    error?: string;
};
export declare function renderEventTexts(events: readonly EventRecord[]): string[];
/** Turn shapes the no-op gate can distinguish. Historical records show bare
 *  "继续"/status-check turns scoring near T and burning the session's single
 *  feedback slot on noise. Tool absence alone must never trigger the gate:
 *  explanations, design answers, and pure Q&A are legitimately tool-free and
 *  stay fully verifiable. */
export type TurnKind = 'task' | 'pure-answer' | 'status-continuation' | 'repair-followup' | 'no-task';
/** True only when the WHOLE prompt is a bare continuation/status ping — never when
 *  it carries any additional instruction ("继续修 OX 模型" stays a real task). */
export declare function isBareContinuationPrompt(problem: string): boolean;
export interface TurnShape {
    problem: string;
    hasCurrentDirectTask: boolean;
    toolEventCount: number;
    /** false = no direct user task in the current OR historical log; legacy callers omit it */
    hasAnyDirectTask?: boolean;
}
export interface TurnClassification {
    kind: TurnKind; /** set only when automatic verification would evaluate pure noise */
    skipReason?: 'bare-status-continuation' | 'evidence-free-repair-followup';
}
/** Classifies a finished turn from values traceFor already computed.
 *  - repair-followup: no direct human task in this turn (verifier feedback or a
 *    plugin injection triggered it); the previous task stays under review.
 *  - status-continuation: bare "继续"-style prompt AND zero tool events — the only
 *    class the gate skips. Every other shape keeps being verified. */
export declare function classifyTurn(shape: TurnShape): TurnClassification;
export interface FindingCitationAudit {
    findingPresent: boolean;
    noDefectFinding: boolean;
    citedIds: number[];
    /** cited ids that do not exist in this turn's rendered trace */
    unknownIds: number[];
    /** cites the omitted historical-verdict marker line */
    citesHistoricalVerdict: boolean;
    /** at least one citation resolves to a real, non-verdict trace line */
    validCitation: boolean;
    /** at least one citation resolves to independent execution evidence (tool result).
     *  Without provenance metadata this equals validCitation (legacy behavior). */
    independentCitation: boolean;
    /** the finding cites real lines but only claims (assistant/user), never tool results */
    citesOnlyClaims: boolean;
}
/** Validates the [E*] references a finding makes against the ids traceFor
 *  assigned. Purely descriptive: the Host marks bad citations, it never
 *  rewrites or discards the model's conclusion by keyword. When per-line
 *  provenance is supplied, only tool results count as independent execution
 *  evidence — assistant prose and user lines are claims or task statements. */
export declare function auditFindingCitation(finding: string | undefined, evidenceIds: readonly number[], verdictLineIds: readonly number[], evidenceKinds?: ReadonlyMap<number, string>): FindingCitationAudit;
/** Record-level rollup over valid lanes: only defect findings must cite;
 *  "no concrete defect" findings are exempt by design. When provenance is
 *  supplied, findings that cite only claims (never tool results) are counted
 *  as lacking independent evidence. */
export declare function auditAggregateCitations(result: AggregateResult, evidenceIds: readonly number[], verdictLineIds: readonly number[], evidenceKinds?: ReadonlyMap<number, string>): {
    defectFindings: number;
    defectFindingsWithoutCitation: number;
    findingsCitingUnknownIds: number;
    findingsCitingHistoricalVerdict: number;
    findingsWithoutIndependentCitation: number;
};
/** Pure decision used by the host idle path: force (manual POST /verify) always
 *  verifies EXCEPT when the session has no direct task at all — a run without a
 *  task cannot name what it verifies, so placeholder verification is skipped
 *  unconditionally (it would burn five lanes and can consume feedback quota). */
export declare function turnGateDecision(shape: TurnShape, options?: {
    force?: boolean;
    skipEnabled?: boolean;
}): {
    verify: boolean;
    kind: TurnKind;
    skipReason?: string;
};
/** Durable count of verifier feedback messages already delivered in this session,
 *  derived from the append-only session event log so it survives hot reloads. */
export declare function feedbackSentCount(events: readonly EventRecord[]): number;
/** Single prompt budget shared with buildVerifierPrompt (ruling J.4-E-3):
 *  a compacted trace must NEVER exceed what the prompt builder accepts, so the
 *  old 18000→16000 double truncation can never tail-cut the final answer. */
export declare const TRACE_BUDGET_CHARS = 16000;
export declare function compactTrace(rendered: readonly string[]): {
    trace: string;
    visibleIds: number[];
    droppedRanges: string[];
    toolEventCount: number;
    traceChars: number;
    evidenceSignalCount: number;
    passSignalCount: number;
    evidenceSummaryChars: number;
};
/** Provenance class of a rendered line. Only tool results are independent
 *  execution evidence; assistant prose is a claim, and user lines define the
 *  task rather than prove it. */
export type EvidenceKind = 'user' | 'tool-call' | 'tool-result' | 'assistant' | 'verdict-marker' | 'other';
/** Exported for the evaluation harness: builds problem + compacted trace exactly as production does.
 *  `evidenceIds` is the FULL rendered set (statistics only); citation audits
 *  must run against `visibleEvidenceIds` — the ids that actually survived
 *  compaction into the verifier prompt (ruling J.4-E, B-6). */
export declare function traceFor(events: readonly EventRecord[], bounds: {
    start: EventRecord;
    end: EventRecord;
    turn?: number;
}): {
    problem: string;
    hasCurrentDirectTask: boolean;
    hasAnyDirectTask: boolean;
    trace: string;
    evidenceIds: number[];
    visibleEvidenceIds: number[];
    verdictLineIds: number[];
    evidenceKinds: Record<string, EvidenceKind>;
    stats: {
        eventCount: number;
        renderedEventCount: number;
        toolEventCount: number;
        traceChars: number;
        evidenceSignalCount: number;
        passSignalCount: number;
        evidenceSummaryChars: number;
    };
};
export declare class VerifierHost {
    private readonly ctx;
    private config;
    private readonly agents;
    /** per-agent status-listener revocation, keyed by agent id */
    private readonly agentListeners;
    private readonly records;
    private readonly listeners;
    private readonly disposers;
    private readonly coordinator;
    private disposed;
    /** null disables persistence (tests/embedded use); the injected Host enables it */
    private readonly recordsFile;
    private readonly feedbackTimeoutMs;
    /** Best-of-N selection host (manual trigger plus first-step autopilot). */
    readonly selections: SelectionHost;
    /** Autopilot winners live only until the source turn reaches idle. */
    private readonly autopilotCleanup;
    /** Background selections are cancelled when their source session disappears. */
    private readonly autopilotActive;
    /** Candidate-model liveness prober, memoized per (baseURL, key) pair so
     *  config churn never keeps a stale credential around. */
    private proberState;
    private proberFor;
    constructor(ctx: HostContext, config: Config, options?: {
        recordsFile?: string | null;
        feedbackTimeoutMs?: number;
        selectionsFile?: string | null;
        selectionsTesting?: ConstructorParameters<typeof SelectionHost>[0]['testing'];
    });
    private handleAutopilotPreStep;
    private cleanupAutopilotWinners;
    /** One concise settlement notice into the source session: the outcome lands
     *  where the operator is looking instead of only in the panel. The distinct
     *  plugin sub-identity ('…/selection') keeps it out of feedback quota,
     *  verifier evidence, and selection seed extraction. Never throws. */
    private notifySelectionSettlement;
    start(): void;
    /** Reload recovery (live incident sel-ac04cfd7, 2026-09-09): a plugin hot
     *  reload disposes the background waiter, so a settled autopilot fallback/
     *  winner could sit retained forever with its relay never delivered. On
     *  startup, re-deliver the relay for any newly-settled record whose source
     *  agent is still alive, and re-register the retained workspace so idle /
     *  dispose cleanup picks it up exactly once. */
    private recoverAutopilotRelays;
    dispose(): Promise<void>;
    setConfig(patch: Partial<Config>): void;
    getConfig(): Config;
    getCredentials(): Credentials | undefined;
    replaceConfig(next: Config): void;
    subscribe(listener: () => void): () => void;
    /** A single broken SSE connection must never break verification or config
     *  operations: listener exceptions are contained here. */
    private emit;
    private attach;
    /** agent/disposed: revoke the status listener and scheduler state so stale
     *  callbacks cannot start verification for an agent that no longer exists. */
    private detach;
    /** Fully synchronous: a status callback can never float a promise, so a
     *  trace/provider failure cannot become an unhandled rejection. */
    private handleStatus;
    /** Coordinator seam: every run gets an abort signal plus an immutable config
     *  snapshot; configuration updates mid-flight affect only future runs. */
    private executeEntry;
    private verifyAgent;
    verifySession(sessionId: string): Promise<RecordState | undefined>;
    snapshot(): Record<string, unknown>;
    private loadHistory;
    private persist;
    /** Newest-first history view with optional filters for the /records endpoint. */
    queryRecords(filter?: {
        sessionId?: string;
        status?: string;
        turn?: number;
    }): RecordState[];
}
/** Fixed-window quota for provider-spending endpoints (Phase 1 egress policy):
 *  local callers get bounded /eval, /probe, and manual /verify spend per minute
 *  instead of an unthrottled lever on the external provider. */
export declare const API_RATE_LIMITS: {
    evalPerMinute: number;
    probePerMinute: number;
    verifyPerMinute: number;
    selectPerHour: number;
};
/** Sliding-window limiter on a stamp log: no fixed-window boundary burst
 *  (2x-at-the-edge is impossible in ANY window of windowMs). acquire() =
 *  peek+commit in one step; /select splits them so admissions rejected by the
 *  host (busy, bad route, missing key) never burn provider-spend quota. */
export interface RateLimiter {
    (): boolean;
    peek(): boolean;
    commit(): void;
}
/** Exported for regression tests; the clock is injectable for deterministic windows. */
export declare function createRateLimiter(limit: number, windowMs: number, now?: () => number): RateLimiter;
/** Exported for regression tests: builds the Host API routes for this host. */
export declare function apiRoutes(host: VerifierHost): WebRoute[];
export declare function apply(ctx: HostContext, config?: Config): void;
