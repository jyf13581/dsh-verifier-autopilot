import type { Config } from './index.js';
type Credentials = {
    resolve?: (ref: string) => Promise<{
        value?: string;
    } | undefined>;
};
export interface RouteResult {
    route: number;
    ok: boolean;
    /** upstream HTTP status when a response was actually received */
    httpStatus?: number;
    score?: number;
    baseline?: number;
    content?: string;
    reasoningSource?: 'content' | 'reasoning_content' | 'none';
    tagA?: boolean;
    tagB?: boolean;
    logprobs?: boolean;
    finishReason?: string;
    errorCode?: string;
    error?: string;
    scoreALabel?: string;
    scoreBLabel?: string;
    /** 'logprobs' = expected-value over token distribution; 'label' = explicit letter without logprobs */
    scoreSource?: 'logprobs' | 'label';
    lane?: string;
    finding?: string;
    /** set when this result required the single transient-error retry */
    retried?: boolean;
    /** uncapped finding line; citation auditing reads this so the 320-char
     *  display truncation can never lose tail [E*] references */
    findingFull?: string;
    durationMs: number;
}
export interface AggregateResult {
    results: RouteResult[];
    valid: RouteResult[];
    mean: number | null;
    median: number | null;
    dispersion: number | null;
    score: number | null;
    baseline: number | null;
    confidence: 'none' | 'low' | 'medium' | 'high';
}
export declare function buildVerifierPrompt(problem: string, trace: string, criterion: string): string;
export type VerifierEffort = 'off' | 'low' | 'high' | 'max';
/** Chat-completions body fields for the configured thinking strength ('思考强
 *  度'). Mirrors llm-verifier's deepseek_reasoning_params(): 'off' explicitly
 *  disables thinking so a relay-side default cannot silently spend the score
 *  budget; anything else enables thinking and passes the effort level through.
 *  An absent/unknown value adds NOTHING — the historic pre-effort payload. */
export declare function verifierEffortFields(effort: unknown): Record<string, unknown>;
export declare function resolveKey(credentials: Credentials | undefined, ref: string): Promise<string | undefined>;
export declare function normalizeBaseUrl(value: string): string;
export interface VerifyOptions {
    /** External abort signal (run-level fence); combined with the per-request timeout. */
    signal?: AbortSignal;
    /** Token-bucket smoother shared across lanes: spaces request dispatches so a
     *  concurrent fan-out cannot self-inflict a rate-limit burst. Optional. */
    smoother?: RequestSmoother;
    /** Per-lane model override (layered tiering): mechanical lanes may run a
     *  cheap model while hard lanes stay on the configured verifier model. */
    modelOverride?: string;
}
/** Minimum spacing between verifier request dispatches (token-bucket smoothing).
 *  Serializes acquire() calls through one chain so N concurrent lanes launch
 *  at >= minIntervalMs apart. minIntervalMs <= 0 returns a no-op smoother. */
export interface RequestSmoother {
    acquire(): Promise<void>;
}
export declare function createRequestSmoother(minIntervalMs: number): RequestSmoother;
/** Mechanical session-verifier lenses that may run on the layered small model
 *  (config.verifierSmallModel) when the operator opts in. Hard lanes —
 *  adversarial/repair and requirement mapping — always stay on the main model. */
export declare const SMALL_MODEL_LENSES: Set<string>;
/**
 * Egress redaction policy (Phase 1): credentials must not leave the process
 * inside verifier prompts. Explicit literals (first and foremost the resolved
 * API key) are replaced before well-known token shapes are pattern-redacted.
 * Idempotent: '[REDACTED]' markers never match again.
 */
export declare function redactSecrets(text: string, extraLiterals?: readonly string[]): string;
export declare function verifyRoute(config: Config, credentials: Credentials | undefined, prompt: string, route: number, options?: VerifyOptions): Promise<RouteResult>;
export declare function verifyFive(config: Config, credentials: Credentials | undefined, prompt: string, options?: VerifyOptions): Promise<AggregateResult>;
export interface FeedbackDecision {
    feedback: boolean;
    /** true when a base trigger fired but the divergence guard suppressed it */
    guarded: boolean;
}
/** Valid lanes whose finding line reports no concrete defect. */
export declare function noDefectLaneCount(result: AggregateResult): number;
/**
 * Divergence-trigger guard (2026-08-25 eight-round eval baseline): when the median
 * stays high and a majority of valid lanes report no concrete defect, a low-mean or
 * high-dispersion trigger comes from single-lane sampling noise, not a real defect.
 * Simulated over 56 eval rows before rollout: suppresses 6/6 false positives while
 * losing 0/32 detections (defect-scenario medians never exceeded 0.368).
 */
export declare function divergenceGuardBlocks(result: AggregateResult, config: Config): boolean;
export declare function decideFeedback(result: AggregateResult, config: Config): FeedbackDecision;
export declare function shouldRequestFeedback(result: AggregateResult, config: Config): boolean;
export {};
