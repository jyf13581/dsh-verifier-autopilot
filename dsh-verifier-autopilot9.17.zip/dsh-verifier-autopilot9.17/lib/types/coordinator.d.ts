/**
 * Per-session verification scheduler.
 *
 * Legacy verifier scheduling boundary (HANDOFF.md §7.1): the mutual-exclusion semantics
 * of verification runs live here instead of inside the cordus-coupled
 * VerifierHost, so overlap, queueing, disposal, and stale-listener behavior can
 * be tested deterministically without a live DSH runtime or provider.
 *
 * Invariants (each pinned by a regression test):
 * - At most one run per session is active at any time; a run's completion is
 *   the only thing that starts the next queued entry.
 * - Pending automatic entries collapse to the newest turn ("latest wins");
 *   pending manual entries are never dropped and jump ahead of autos because a
 *   human is synchronously waiting on the response.
 * - A manual entry resolves with the outcome of its OWN run, never another
 *   session's or a newer queued run.
 * - Disposal aborts active controllers, settles every waiter as aborted, and
 *   refuses further scheduling; forgetting a session clears its dedupe marker
 *   and pending entries so stale callbacks cannot start anything new.
 */
export interface ScheduledEvent {
    type: string;
    seq?: number;
    time?: number;
    data?: any;
}
export type TurnBounds = {
    start: ScheduledEvent;
    end: ScheduledEvent;
    turn: number;
};
export type ScheduleKind = 'auto' | 'manual';
export interface ScheduleEntry<A> {
    readonly sessionId: string;
    readonly agent: A;
    readonly bounds: TurnBounds;
    readonly kind: ScheduleKind;
}
export interface RunContext {
    /** Aborted when the coordinator is disposed; the run must stop side effects. */
    readonly signal: AbortSignal;
}
export type EntryOutcome<T> = {
    status: 'completed';
    value: T;
} | {
    status: 'aborted';
} | {
    status: 'failed';
    error: unknown;
};
export interface CoordinatorHooks<A, T> {
    /** Performs the actual verification for one entry. Implementations must
     *  settle every run into a terminal state; a rejection only means the entry
     *  produced no value. */
    run(entry: ScheduleEntry<A>, context: RunContext): Promise<T>;
}
export declare class VerificationCoordinator<A, T = unknown> {
    private readonly hooks;
    private readonly sessions;
    private disposed;
    constructor(hooks: CoordinatorHooks<A, T>);
    /** Automatic idle path. Returns false when the entry was refused (disposed
     *  host) or deduplicated (this completed turn was already seen). */
    scheduleAuto(sessionId: string, agent: A, bounds: TurnBounds): boolean;
    /** Manual path: joins the same per-session queue (mutual exclusion applies),
     *  never gets dropped by later arrivals, and resolves with its own run's
     *  outcome once that run actually executes. */
    scheduleManual(sessionId: string, agent: A, bounds: TurnBounds): Promise<EntryOutcome<T>>;
    /** The agent went away: revoke scheduler state so stale status callbacks and
     *  queued turns cannot start anything new. An already-active run is left to
     *  reach its terminal record on its own. */
    forgetSession(sessionId: string): void;
    dispose(): void;
    isActive(sessionId: string): boolean;
    pendingCount(sessionId: string): number;
    sessionCount(): number;
    isDisposed(): boolean;
    private sessionOf;
    private pump;
    private cleanupIdleSession;
}
